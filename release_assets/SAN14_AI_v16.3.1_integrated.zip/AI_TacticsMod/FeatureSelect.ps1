﻿# Feature selection for AI_TacticsMod\기능설정.ini (UTF-16, read by the DLLs at game start).
# Dot-sourced by 관리.ps1. Each DLL reads [section] key, then the legacy [features] key,
# then its default, so files written by older installers keep their values.
# Items that share game code are one switch (see each note); they cannot be split.
# Registered raw settings (not 0/1 switches): edited by the game's first-menu 「조조전」 dialog.
# Missing/empty profile keeps current art, 70/90 thresholds and all existing personal formations.
$taskRawSettings = @('ccz_appearance.profile','tactic_priority.profile')
# v12.8: Requires = parent feature that must also be on (DLL ANDs it); Inherit = the switch an
# older file's missing key falls back to. Tab is the GUI installer tab (installer/InstallerGui.cs).
$taskFeatureCatalog = @(
    @{Group='convenience'; Section='real_estate'; Key='terrain_edit'; Default=1; Requires='game_flow.advisor_briefing'; Inherit=''; Tab='편의성'; Label='부동산 계획: 지형 변경'; Note='원작: 지형은 바꿀 수 없습니다. / 변경: 군사 보고 창의 「부동산 개발」 버튼 → 내 성 선택 → 그 성의 지역내정에서 땅을 클릭해 바닥·높이·나무·절벽·수면을 바꿉니다(무료). / 효과: 내 땅의 지형을 바꿉니다. / 필요: 군사의 열흘 보고'}
    @{Group='convenience'; Section='diplomacy'; Key='diplomacy_overinvest'; Default=0; Requires=''; Inherit=''; Tab='게임성'; Retired=$true; Label='외교 군정 100% 초과 투입'; Note='컴퓨터가 시작한 친선·동맹·포로반환·공격요청 교섭에서 보유 군정까지 투입합니다. 100%를 넘긴 방어 효과는 상대의 추가 투입 후에도 유지됩니다.'}
    @{Group='convenience'; Section='diplomacy'; Key='diplomacy_counterturn'; Default=1; Requires=''; Inherit=''; Tab='게임성'; Label='외교 군정 마지막 추가 대응'; Note='원작: 외교에서 컴퓨터가 마지막으로 군정을 넣으면 바로 판정합니다. / 변경: 그 뒤에 플레이어가 군정을 한 번 더 넣을 수 있습니다. 넣고 나면 바로 판정합니다. / 효과: 마지막 한 수를 내가 둡니다. / 필요: 편의·게임성 기능 전체'}
    @{Group=''; Section='groups'; Key='combat'; Default=1; Requires=''; Inherit=''; Tab='전투'; Label='전투 AI 교정 전체 (SAN14_CombatAI.dll)'; Note='원작: 컴퓨터의 출진·공성·퇴각을 원작 AI만 정합니다. / 변경: 전투 DLL을 불러와, 이 탭의 기능이 원작 AI 판단 앞뒤에 끼어들 수 있게 합니다. / 효과: 끄면 이 탭 전체가 꺼지고 컴퓨터는 원작대로 싸웁니다.'}
    @{Group='combat'; Section='combat'; Key='sortie_formation'; Default=1; Requires=''; Inherit=''; Tab='전투'; Label='컴퓨터 출진 편성 (병력에 맞춘 2~7부대)'; Note='원작: 컴퓨터가 성을 치러 나갈 때 부대 수·장수·진형을 원작 방식으로 고릅니다. / 변경: 병력에 맞춰 2~7부대로 나눕니다. 본대는 공성 진형으로 짭니다. 응원·악주 개성을 가진 통솔 60 미만 여무장만 1,000명 지원 부대로 붙고, 다른 장수는 병력 제한 없이 나갑니다. 주장과 친애인 장수, 범위 개성(효장·독려 등) 장수를 먼저 뽑습니다. 성에 4,000명은 남깁니다. / 효과: 컴퓨터 군세가 대열을 갖춰 나오고, 성을 비우지 않습니다. / 필요: 전투 AI 교정 전체'}
    @{Group='combat'; Section='combat'; Key='departures'; Default=1; Requires=''; Inherit=''; Tab='전투'; Retired=$true; Label='정기 선제 출진 검토 (10일마다)'; Note='임무 일관성 v2와 충돌해 사용이 중지된 기능입니다.'}
    @{Group='combat'; Section='combat'; Key='group_advance'; Default=1; Requires=''; Inherit=''; Tab='전투'; Retired=$true; Label='집결 후 30일 정지 군세의 집단 진군'; Note='임무 일관성 v2와 충돌해 사용이 중지된 기능입니다.'}
    @{Group='combat'; Section='combat'; Key='stationary_retreat'; Default=1; Requires=''; Inherit=''; Tab='전투'; Label='같은 자리 40일 정지 부대 퇴각'; Note='원작: 길이 막힌 부대가 같은 자리에 계속 서 있습니다. / 변경: 4턴(40일) 동안 한 칸도 못 움직인 부대를 성으로 돌려보냅니다. 성을 치는 중인 부대, 사기 회복 대기·방벽 돌파 중인 부대는 제외합니다. / 효과: 길에 멈춰 선 컴퓨터 부대가 사라지고, 그 병력이 다시 쓰입니다. / 필요: 전투 AI 교정 전체'}
    @{Group='combat'; Section='combat'; Key='morale'; Default=1; Requires=''; Inherit=''; Tab='전투'; Label='사기 회복 우선'; Note='원작: 사기가 낮아도 그대로 진군합니다. / 변경: 사기 85 이하인 부대가 5칸 안의 자기 군악대 옆으로 가서 사기 100까지 기다립니다. 사기 70 이하이거나 산지에 있으면 15칸 안까지 찾습니다. 군악대가 없으면 원작 건설 절차로 짓습니다. / 효과: 컴퓨터 부대가 사기를 채우고 싸웁니다. / 필요: 전투 AI 교정 전체'}
    @{Group='combat'; Section='combat'; Key='support'; Default=1; Requires=''; Inherit=''; Tab='전투'; Retired=$true; Label='호위·동행 지원 요청'; Note='임무 일관성 v2와 충돌해 사용이 중지된 기능입니다.'}
    @{Group='combat'; Section='combat'; Key='mission_v2'; Default=1; Requires=''; Inherit=''; Tab='전투'; Label='공성 임무 정리 (시설 1개만 짓고 바로 공격)'; Note='배경: 모드의 옛 공성 진행은 가는 길마다 시설을 짓고 건설을 기다리느라 군세가 멈췄습니다. / 변경: 목표 성 10칸 안 자기 땅, 성에서 3~6칸 지점에 공성 시설 1개만 짓고 기다리지 않습니다. 원작이 이미 목표 성을 치고 있으면 모드가 끼어들지 않습니다. 가는 길의 적 지역은 원작 군세의 작업 목록에 넣어 원작이 점령하게 합니다. 병력이 최대의 90% 이상이고 여유가 4만 이상인 성은 이어진 적 성으로 대열 출진합니다. / 효과: 컴퓨터가 건설에 시간을 버리지 않고 성을 칩니다. / 필요: 전투 AI 교정 전체'}
    @{Group='combat'; Section='combat'; Key='siege_stall_near'; Default=0; Requires='combat.mission_v2'; Inherit=''; Tab='전투'; Label='공성 정체: 성 1칸 안만 공성 중'; Note='배경: "40일 정지 퇴각"은 공성 중인 부대를 제외합니다. 그런데 성 근처에 서 있기만 해도 공성 중으로 봐서, 멈춘 부대가 안 돌아갔습니다. / 변경: 성 1칸 안에 있거나 최근에 성을 때린 부대만 공성 중으로 봅니다. / 효과: 성에서 떨어져 서 있기만 한 부대는 40일 뒤 돌아갑니다. / 필요: 공성 임무 정리'}
    @{Group='combat'; Section='combat'; Key='siege_native'; Default=0; Requires=''; Inherit=''; Tab='전투'; Retired=$true; Label='공성 진행을 원작에 맡기기'; Note='공성 진행은 다시 모드 임무 일관성이 맡아 제거되었습니다.'}
    @{Group='combat'; Section='combat'; Key='siege_ring10'; Default=0; Requires='combat.mission_v2'; Inherit=''; Tab='전투'; Label='공성 시설을 성에서 3~10칸까지 허용'; Note='배경: 공성 임무 정리는 성에서 3~6칸에만 공성 시설을 짓습니다. / 변경: 자리를 3~10칸으로 넓히고, 군악대는 부대 6칸 안에 짓습니다. / 효과: 성 근처에 자리가 없어도 조금 멀리 짓습니다. / 필요: 공성 임무 정리'}
    @{Group='combat'; Section='combat'; Key='siege_no_catapult'; Default=0; Requires='combat.mission_v2'; Inherit=''; Tab='전투'; Label='공성 건설에서 투석대 제외'; Note='배경: 모드 공성 건설은 투석대 → 요새 → 군악대 순서로 짓고, 투석대를 못 지으면 망루를 짓습니다. / 변경: 투석대를 짓지 않습니다. 그 자리는 망루로 채웁니다. 컴퓨터 세력의 자동 시정은 지세연구를 Lv 7 이상 10 미만에서 멈춥니다(투석대가 열리는 Lv 10까지 시정을 쓰지 않음). / 효과: 성 앞에 컴퓨터 투석대가 서지 않고, 컴퓨터 시정이 쓸모없는 지세연구에 낭비되지 않습니다. / 필요: 공성 임무 정리'}
    @{Group='combat'; Section='combat'; Key='siege_no_watchtower'; Default=0; Requires='combat.mission_v2'; Inherit=''; Tab='전투'; Label='공성 건설에서 망루 제외'; Note='배경: 위와 같음. / 변경: 투석대를 못 지을 때 대신 짓던 망루를 짓지 않습니다. / 효과: 성 앞에 컴퓨터 망루가 서지 않습니다. / 필요: 공성 임무 정리'}
    @{Group='combat'; Section='combat'; Key='siege_no_trap'; Default=0; Requires='combat.mission_v2'; Inherit=''; Tab='전투'; Label='공성 건설에서 함정 제외'; Note='배경: 모드 공성 건설은 10% 확률로 함정(불·맹화·낙석·구덩이·화선)을 짓습니다. / 변경: 함정을 짓지 않습니다. / 효과: 성 앞에 컴퓨터 함정이 깔리지 않습니다. / 필요: 공성 임무 정리'}
    @{Group='combat'; Section='combat'; Key='siege_fort_first'; Default=1; Requires=''; Inherit=''; Tab='전투'; Label='성 앞 진 대신 요새·군악대'; Note='원작: 컴퓨터가 성을 칠 때 성 앞에 짓는 시설은 진 하나뿐입니다. / 변경: 같은 자리에 요새를 지을 수 있으면 요새를, 요새가 이미 있거나 못 지으면 군악대를 짓습니다. 둘 다 안 되면 원작대로 진을 짓습니다. / 효과: 컴퓨터 공성 진지가 더 단단해집니다. / 필요: 전투 AI 교정 전체'}
    @{Group='combat'; Section='combat'; Key='retake_adjacent'; Default=1; Requires='combat.mission_v2'; Inherit=''; Tab='전투'; Label='거점 수복 부대 (성 주변 지역 되찾기)'; Note='원작: 성을 지킬 때 요격할지만 검토합니다. 지역을 되찾는 출진은 근처에 적 부대가 있으면 아예 나가지 않습니다. / 변경: 요격과 따로, 성 주변 지역을 되찾는 2,000명 부대를 지역마다 하나씩 보냅니다. 적이 거점 8칸 안으로 다가오면 빼앗기기 전에 미리 나옵니다. 성 지역에 바로 붙은 지역(1차 인접)의 거점 때문에 나가고, 되찾은 뒤에는 그 옆 지역(2차 인접)까지 이어서 갑니다(1차 먼저). 다른 성(어느 세력이든)에 바로 붙은 지역은 건너뛰고, 항구는 우리 성에서 16칸 안의 것만 갑니다. 이 범위에서 적 부대가 가장 많이 몰린 지역 하나는 "최대 위협"으로 보고, 가지도 지나가지도 않습니다. 나머지 거점을 가까운 순서로 차례로 되찾습니다. 서 있지 않고 계속 다음 거점으로 갑니다. 적 부대 옆 칸은 밟지 않고, 완성된 적 투석대(3칸)·망루(2칸) 사정거리는 되도록 피합니다. 목표 지역에 아군 칸이 더 많으면 적 병참 차단을 먼저 시도합니다. / 효과: 컴퓨터가 성 주변 지역 효과를 적극적으로 지키고, 빼앗겨도 뒤집으러 옵니다. / 필요: 공성 임무 정리'}
    @{Group='combat'; Section='combat'; Key='retake_build'; Default=0; Requires='combat.retake_adjacent'; Inherit=''; Tab='전투'; Label='수복 부대의 시설 건설 (하드코어)'; Note='배경: 수복 부대는 기본적으로 시설을 짓지 않고 다음 거점으로 갑니다. / 변경: 거점을 되찾은 뒤 그 지역에 진·요새 같은 시설까지 짓습니다. / 효과: 한 번 빼앗은 지역이 요새화되어 다시 빼앗기가 크게 어려워집니다. / 필요: 거점 수복 부대 / 주의: 매우 하드코어해집니다.'}
    @{Group='combat'; Section='combat'; Key='gate_intercept'; Default=1; Requires='combat.mission_v2'; Inherit=''; Tab='전투'; Label='관문 요격 (안행 2,000명)'; Note='원작: 관문이 공격받아도 요격 부대를 따로 세우지 않고, 원작 판단으로만 출진합니다. / 변경: 컴퓨터 세력의 관문 3칸 안으로 적 부대가 들어오면 그 관문(병사 4,000 이상일 때) 또는 30칸 안의 가장 가까운 아군 성(병사 6,000 이상)에서 안행진 2,000명 부대 하나를 내보냅니다. 부대는 적 - 관문 - 안행진 순서가 되도록 관문 너머 2~3칸에 서서 사정거리에 들어오는 적과 싸웁니다. 원작의 다른 명령은 받지 않고, 적이 자리를 옮기면 따라 서며, 관문 근처에 10일 동안 적이 없거나 관문을 잃거나 병사가 500 밑으로 줄면 돌아갑니다. 안행을 쓸 줄 아는 장수가 없으면 나가지 않습니다. / 효과: 관문을 치는 적이 관문 뒤의 궁병을 상대해야 합니다. / 필요: 공성 임무 정리'}
    @{Group='combat'; Section='combat'; Key='helm_intercept'; Default=1; Requires='combat.mission_v2'; Inherit=''; Tab='전투'; Label='조타 요격 (항구 방어)'; Note='원작: 컴퓨터는 요격을 칸 수 기준으로만 해서 조타(함선에 탄 동안 ZOC 무시) 개성을 수비에 쓰지 못합니다. / 변경: 여강·건업·시상·강하·강릉·장사·무릉을 가진 컴퓨터 세력의 수군 단계가 몽충(수군육성 Lv5) 이상일 때, 그 성에 소속된 아군 항구 지역의 점령 칸이 전날보다 줄면 거리와 상관없이 그 성의 조타 개성 장수가 출진합니다. 병사 수는 진형의 점령 폭이 넓어지는 병력(원작 문턱, 영명 같은 개성이 있으면 줄어듦)에 1,000명을 더한 값이고, 학익진을 먼저 고르고 넓은 폭을 좁은 폭보다 먼저 봅니다. 병력이 모자라면 봉시진, 없으면 추행진, 그것도 없으면 아무 진형으로 3,000명이 나갑니다. 원작의 다른 명령은 받지 않고 그 항구 지역에서 잃은 칸(적 칸 우선, 물 위 가산)을 골라 칠합니다. 매일 칠할 칸을 다시 고르며, 적 부대와 15칸 넘게 떨어져 있으면 벌점 없이 적 쪽 칸으로 다가가고, 15칸 안에 들어오면 적 부대 3칸 안 칸에 큰 벌점을 줍니다. 항구를 잃으면 바로 돌아가지 않고 그 성의 잃은 항구 중 성에서 가장 가까운 곳을 수복(항구 칸 점령)한 뒤 그 항구 지역을 칠합니다. 항구 지역을 모두 되찾았거나, 성에 잃은 항구가 없는데 담당 항구를 잃었거나, 병사가 1,000 밑으로 줄면 돌아갑니다. 무장 순환(swap)이 켜져 있으면 조타 장수는 이 성들 중 하나로 보내지고 다른 곳으로 옮겨지지 않습니다. 단 일곱 성을 모두 한 세력이 가져 강에 다른 세력이 없으면 묶지 않습니다. 조타 장수가 없으면 나가지 않습니다. 성 둘레(성에서 가장 가까운 대하까지 거리+10칸, 최소 15칸) 안의 대하·격류 칸 중 아군 칸이 전날보다 줄어도 출진해 잃은 칸이 가장 많은 지역부터 칠하고, 그 범위에 잃은 대하·격류 칸이 없어지면 임무를 마칩니다(칠할 칸에 사흘 연속 못 가면 바로 돌아감). 항구뿐 아니라 강물 칸이 3칸 이상인 그 성의 지역(건업 본 지역처럼 장강에 닿은 곳)도 지키며, 칠할 칸은 강물 칸이나 적이 아닌 강기슭만 고르고, 적 칸으로 칠해진 육지에는 올라가지 않습니다(물 위에서 둘레 칸만 뒤집음). 적의 완성된 투석대(사거리 3)·망루(사거리 2) 사거리 안 칸은 목표로 고르지 않고 지나가는 길도 피합니다(공성 임무 부대는 지금처럼 상륙해 부숨). 중계점이 맡은 지역에서 모자라면 같은 성의 다른 지역·강 둘레로 이어 찍고, 그래도 경로 합이 15칸이 안 되면 아군 물 칸까지 중계점으로 찍어 한 번에 멀리 움직이고, 지역을 옮긴 날도 바로 움직입니다. 항구 지역을 다 되찾아도 그 성 둘레 강에 잃은 칸이 있으면 돌아가지 않고 강 임무로 넘어갑니다. 맡은 지역을 되찾으면 같은 성의 다른 지역에 칠할 칸이 남아 있으면 그쪽으로 옮겨 계속 칠합니다. 돌아갈 이유(병사 부족·항구 상실·항구 지역 회복)가 생겨도 2턴 동안 주변의 물 위 적 칸을 칠하다가 돌아가고, 2턴이 끝날 때 항구 지역의 적 칸이 그사이 늘었고 항구 6칸 안에 적 부대가 있으면(병사 1,000명 이상일 때) 새 목표를 잡아 2턴 더 칠합니다. 성이 공격받으면 바로 돌아갑니다. / 효과: 항구 지역 점령률을 지켜 병참을 지킵니다. / 필요: 공성 임무 정리'}
    @{Group='combat'; Section='combat'; Key='garrison_recall'; Default=1; Requires='combat.mission_v2'; Inherit=''; Tab='전투'; Label='성 병사 회수 (내구보다 병사 많게)'; Note='원작: 성이 공격받는 중에도 밖에 나간 요격·수복 부대는 하던 일을 계속하므로, 성 병사가 내구보다 먼저 0이 되어 함락되는 일이 잦습니다. / 변경: 컴퓨터 세력의 성 3칸 안에 적 부대가 있고 성 병사가 성 내구 이하이면, 그 성에서 나간 아군 부대(모드의 수복·요격·조타 부대와 원작 요격 부대 모두)를 20칸 안에서 가까운 순서로 귀환시킵니다. 귀환 중인 병사를 더해 내구보다 많아지면 멈춥니다. 귀환 명령은 원작 명령으로 덮어쓰이지 않습니다. / 효과: 성 병사가 내구보다 먼저 바닥나 함락되는 일이 줄어듭니다. / 필요: 공성 임무 정리'}
    @{Group='combat'; Section='combat'; Key='computer_trade'; Default=1; Requires=''; Inherit=''; Tab='전투'; Label='컴퓨터 교역국 교역 (통솔 70 미만 특사·정치 무장)'; Note='원작: 컴퓨터 세력은 지역 이점으로 교역국(대진국·안식(파르티아) 등)이 열려 있어도 교역 조건(본거지 금 9000·병량 30000·병사 6000, 도시 무장 8명 이상, 주의 목록 비어 있음)이 까다로워 교역을 거의 보내지 않습니다. / 변경: 컴퓨터 세력은 매달 상순에 한 번, 열려 있고 지금 교역 중이 아닌 교역국 중 우호도가 가장 낮은 곳으로 교역을 보냅니다. 전선이 아닌 자기 세력 도시(모든 군단)에서 쉬고 있는 통솔 70 미만 무장(군주·태수 제외) 중 특사 개성 보유자를 먼저, 그다음 통솔 50 미만, 그다음 정치가 높은 순으로 최대 3명(우호도 1000이면 1명) 보냅니다. 함께 가는 무장은 다른 도시에 있어도 됩니다(원작과 같음). 본거지에 금 8000·병사 5000 이상, 필요 병량+10000 이상이 있어야 합니다. 원작 교역 명령도 같은 무장 선택을 씁니다. / 효과: 컴퓨터 세력이 교역국 우호도를 꾸준히 올려 명품·교역특전·전법서를 얻습니다.'}
    @{Group='combat'; Section='combat'; Key='front_hire'; Default=1; Requires=''; Inherit=''; Tab='전투'; Label='전선 도시 고용무장 개성 선별'; Note='원작: 컴퓨터 세력은 고용 가능한 무장 목록의 첫 사람을 개성과 상관없이 고용합니다. / 변경: 적 세력과 맞닿은 전선 도시에서는 응원·악주(지원 부대), 조타(조타 요격), 모집(모병 담당관) 개성 보유자만 고용합니다. 해당자가 없으면 그 차례에는 고용하지 않습니다(고용무장 개성은 매달 상순에 바뀝니다). 후방 도시와 플레이어 세력은 원작 그대로입니다. / 효과: 전선 도시에 쓸모 있는 고용무장이 모입니다.'}
    @{Group='combat'; Section='combat'; Key='ranged_facility_kill'; Default=1; Requires=''; Inherit=''; Tab='전투'; Label='원거리 공격으로 시설 파괴'; Note='원작: 안행 같은 원거리 부대가 떨어진 곳에서 망루·투석대·요새 같은 시설을 치면 내구가 1에서 더 줄지 않습니다. 바로 붙어서 쳐야만 부술 수 있습니다. / 변경: 시설(망루·투석대·진·요새·성벽·함정 등)은 떨어져서 쳐도 내구가 0이 되어 무너집니다. 성과 관문은 원작대로입니다. / 효과: 원거리 부대가 적 시설을 직접 정리할 수 있습니다. 플레이어와 컴퓨터 모두 같습니다.'}
    @{Group='combat'; Section='combat'; Key='builder_ruler_fill'; Default=0; Requires='combat.mission_v2'; Inherit=''; Tab='전투'; Label='건설 성향 군주는 지역을 시설로 채움'; Note='배경: 공성 임무 정리는 누구든 공성 시설을 1개만 짓게 합니다. / 변경: 내면 "건설"이 5인 컴퓨터 군주의 부대는 지역이 찰 때까지 시설을 계속 짓습니다. / 효과: 그런 군주와 싸울 때 시설이 훨씬 많이 깔립니다. / 필요: 공성 임무 정리'}
    @{Group='combat'; Section='combat'; Key='ai_max_aggression'; Default=1; Requires=''; Inherit=''; Tab='전투'; Label='AI 호전성 최대 (궁극과 같은 공격 검토)'; Note='원작: 컴퓨터의 공격 검토 범위와 빈도가 게임 설정의 AI 단계에 따라 달라집니다. 낮은 단계에서는 검토를 몇 턴씩 건너뜁니다. / 변경: AI 단계를 늘 "궁극"으로 읽게 하고, 턴 건너뛰기를 없앱니다. / 효과: 어떤 설정에서도 컴퓨터가 가장 공격적으로 움직입니다. / 필요: 전투 AI 교정 전체'}
    @{Group='combat'; Section='combat'; Key='ai_wall_block'; Default=1; Requires=''; Inherit=''; Tab='전투'; Label='컴퓨터 세력 방벽 건설 금지'; Note='원작: 컴퓨터가 토성·석벽을 짓습니다. 그런데 컴퓨터는 방벽을 활용하지 못해서, 자기 길만 막는 의미 없는 방벽이 많습니다. / 변경: 컴퓨터가 토성·석벽을 새로 짓지 못하게 합니다. / 효과: 컴퓨터가 쓸모없는 방벽으로 자기 진군로를 막지 않습니다. / 필요: 전투 AI 교정 전체'}
    @{Group='combat'; Section='combat'; Key='ai_catapult_block'; Default=0; Requires=''; Inherit=''; Tab='전투'; Label='플레이어 성 주변 컴퓨터 투석대 건설 불가'; Note='배경: 모드의 공성 건설은 투석대를 먼저 짓습니다. 그래서 컴퓨터가 내 성 앞에 투석대를 세웁니다. / 변경: 플레이어 성·관문이 있는 지역과 그 바로 옆 지역에서는 컴퓨터가 투석대를 지을 수 없습니다. 그곳에서는 요새가 최고 시설이 되어, 컴퓨터는 요새 등 다른 시설을 짓거나 공성을 계속합니다. / 효과: 내 성이 컴퓨터 투석대에 맞지 않습니다. / 필요: 전투 AI 교정 전체'}
    @{Group='combat'; Section='combat'; Key='combat_cut'; Default=1; Requires=''; Inherit=''; Tab='전투'; Label='컴퓨터 군세의 플레이어 병참선 차단'; Note='원작: 병참 차단은 통솔이나 지력이 64를 넘는 장수만 시도하고, 대상을 가리지 않습니다. 모드가 관리하는 군세는 다른 임무가 먼저라 차단 판단까지 가지 못했습니다. / 변경: 급한 임무가 없는 컴퓨터 부대는 원작의 병참 차단 판단을 먼저 탑니다. 대상은 플레이어 부대로 좁힙니다. 차단을 시작하면 끝날 때까지 유지합니다. / 효과: 컴퓨터가 내 부대의 병참을 끊으러 옵니다. / 필요: 전투 AI 교정 전체'}
    @{Group='combat'; Section='combat'; Key='hit_response'; Default=1; Requires=''; Inherit=''; Tab='전투'; Label='피격 대응 (적 성·관문 피격 시 공성 고정, 피격 부대 보호)'; Note='배경: 모드가 "누가 누구를 때렸는지"를 기록하는 기능입니다. 다른 판단이 이 기록을 씁니다. / 변경: 적 성·관문에 실제로 피해를 준 부대는 그 성 공격을 계속하도록 고정합니다. 맞아서 병력이 1,000명 아래로 떨어진 부대는 돌려보냅니다. / 효과: 컴퓨터가 치던 성을 두고 딴 데로 가지 않습니다. / 필요: 전투 AI 교정 전체'}
    @{Group='combat'; Section='combat'; Key='obstacle'; Default=1; Requires=''; Inherit=''; Tab='전투'; Label='중립 장애물 파괴 판단'; Note='원작: 컴퓨터는 중립 토성·석벽·철쇄를 부술지 스스로 잘 판단하지 못합니다. / 변경: 두 경우에만 중립 방벽을 부숩니다. ① 방벽 너머에서 플레이어의 안행·수상 진형 부대나 망루·투석대·망대에게 맞았고, 쏜 쪽까지 방벽을 돌아가는 길이 2칸 이상 길거나 없을 때(가까우면 돌아갑니다). ② 방벽 앞에서 같은 구간을 왔다 갔다 하며 막혔을 때. / 효과: 컴퓨터 군세가 방벽 뒤에서 일방적으로 맞거나 방벽 앞에서 멈추지 않습니다. / 필요: 전투 AI 교정 전체'}
    @{Group='combat'; Section='combat'; Key='path_wall'; Default=0; Requires='combat.obstacle'; Inherit=''; Tab='전투'; Label='중립 방벽 돌파 (가장 짧은 길을 막을 때)'; Note='원작: 중립 방벽이 길을 막으면 먼 길로 돌아갑니다. / 변경: 방벽이 없다고 친 길보다 돌아가는 길이 5칸 이상이고 4분의 1 이상 길거나 길이 아예 없으면, 가장 가까운 부대 하나가 방벽을 부숩니다. 또 같은 성에서 나오는 5번째 부대마다 성 옆 중립 방벽 하나를 부수러 갑니다. 방벽이 무너질 때까지 명령을 유지합니다. / 효과: 컴퓨터가 방벽을 뚫고 짧은 길로 옵니다. / 필요: 중립 장애물 파괴 판단'}
    @{Group='combat'; Section='combat'; Key='supply_relay'; Default=1; Requires=''; Inherit=''; Tab='전투'; Label='목표를 바꿀 때 병참 잇기'; Note='원작: 적 지역 안에 우리 부대가 하나뿐일 때 그 부대가 떠나면, 턴 처리에서 적 지역담당관이 칸을 되찾아 병참이 끊깁니다. / 변경: 그런 상황에서 목표가 바뀌면, 뒤쪽 아군 지역의 아군 칸 하나를 먼저 밟고 새 목표로 갑니다. 그 지역 거점이 더 가까우면 거점을 먼저 점령합니다. / 효과: 컴퓨터 부대가 혼자 병참이 끊겨 무너지는 일이 줄어듭니다. / 필요: 전투 AI 교정 전체'}
    @{Group='combat'; Section='combat'; Key='no_tribe_target'; Default=1; Requires=''; Inherit=''; Tab='전투'; Label='이민족 성 공격 금지 (모드 보호용)'; Note='원작: 컴퓨터는 이민족 성을 공격 목표로 삼지 않습니다(차지할 수 없습니다). / 배경: 모드가 새 공격 경로(공격 검토 완화, 대열 출진)를 만들면서 이 금지를 거치지 않는 길이 생겼습니다. / 변경: 원작 공격 검토와 모드의 목표 선택 양쪽에서 이민족 성을 목표에서 뺍니다. 이미 향하던 군단은 다음 재검토에서 물러납니다. / 효과: 컴퓨터가 차지할 수 없는 성에 병력을 버리지 않습니다. / 필요: 전투 AI 교정 전체'}
    @{Group='combat'; Section='combat'; Key='tribe_terrain_path'; Default=1; Requires=''; Inherit=''; Tab='전투'; Label='장사·사이 진형 숲·산 경로'; Note='원작: 장사·사이 진형은 숲·밀림·저산·중산·고산·산길에서 1.5배 보너스를 받지만, 컴퓨터는 경로를 가도로 잡는 일이 많습니다. / 변경: 컴퓨터 부대가 장사·사이 진형이고 15칸 안에 적 부대가 있을 때만, 길 찾기 비용에서 숲·산이 아닌 육지 칸 비용을 약 3.3배로 매깁니다. 적이 없거나, 사기가 50 밑이면(숲·산은 5일마다 사기가 더 깎임) 원작대로 가도·평지로 이동합니다. 목적지(공격 대상)는 원작 판단 그대로라, 적이 평지에 있으면 숲·산으로 붙어 가다가 마지막에 평지로 나옵니다. 실제 이동 속도·표시 기동·물 위·거점 칸·플레이어(직할·위임) 부대는 바뀌지 않습니다. / 효과: 적 근처에서 보너스 지형을 타고 이동합니다. / 필요: 없음'}
    @{Group='combat'; Section='combat'; Key='ai_tactic_order'; Default=1; Requires=''; Inherit=''; Tab='전투'; Label='컴퓨터 출진 전법 우선순위'; Note='원작: 컴퓨터 부대가 출진할 때 가져갈 전법 3개를 원작 기준으로 고릅니다. / 변경: 컴퓨터 군단(플레이어 직할·위임 군단 제외)의 출진 부대는 그 진형에서 쓸 수 있는 전법 중 고유전법 > 교역전법(아수라진·구갑대열·안식사법) > 다른 이민족 전법 > 무력형(무력≥지력) 연노·매성·도발·혼란·급습·분전·저지·돌격·대갈·제사·경파 / 지력형 매성·혼란·업화·화시·도발·저지·대갈 > 나머지 순으로 3개를 가져갑니다. 쓸 수 있는 전법이 없으면 원작 선택을 둡니다. / 효과: 강한 전법을 먼저 씁니다. / 필요: 없음'}
    @{Group='combat'; Section='combat'; Key='recall_veto'; Default=1; Requires=''; Inherit=''; Tab='전투'; Label='갓 출진한 공격 군단의 회군 방지'; Note='원작: 군세를 매일 다시 판단해서, 막 나온 군세를 성을 나서기도 전에 되돌리기도 합니다. / 변경: 출진 10일 안, 합계 3,000명 이상인 공격 군세는 목표가 여전히 적 성이면 되돌리지 못하게 합니다. / 효과: 컴퓨터가 나왔다가 바로 들어가는 일이 줄어듭니다. / 필요: 전투 AI 교정 전체'}
    @{Group=''; Section='groups'; Key='convenience'; Default=1; Requires=''; Inherit=''; Tab='편의성'; Label='편의·게임성 기능 전체 (SAN14_Convenience.dll)'; Note='변경: 편의 DLL의 편의성·게임성 기능을 켭니다. / 효과: 끄면 편의성·게임성·조조전 탭과 빠른 저장이 모두 꺼집니다.'}
    @{Group='convenience'; Section='battle_rules'; Key='battle_rules'; Default=1; Requires=''; Inherit=''; Tab='편의성'; Label='숙련 모드 공방 설정 + 인접지역 효과'; Note='원작: 숙련 설정에 자세력·타세력 기본 공방과 인접 지역 효과를 고르는 줄이 없습니다. 인접 지역 효과는 지역당 4% 고정입니다. / 변경: 설정 화면에 네 줄(자세력/타세력 기본 공방 50~200, 인접 지역 효과 0~200)을 더합니다. / 효과: 전투 난이도를 내 취향으로 맞춥니다. / 필요: 편의·게임성 기능 전체 / 주의: 값을 바꾼 세이브는 이 항목을 켠 채로 이어 하세요.'}
    @{Group='convenience'; Section='battle_rules'; Key='expert_ingame'; Default=0; Requires='battle_rules.battle_rules'; Inherit=''; Tab='편의성'; Label='숙련 설정 게임 중 변경'; Note='원작: 숙련 설정은 게임 중에는 볼 수만 있습니다. / 변경: 게임 중 설정 화면에서 위 네 줄을 바꾸고 확인으로 적용합니다. / 효과: 새 게임을 시작하지 않고 난이도를 고칩니다. / 필요: 숙련 모드 공방 설정'}
    @{Group='convenience'; Section='personnel'; Key='awards'; Default=1; Requires=''; Inherit=''; Tab='편의성'; Label='명품창고·6슬롯·명품/관직 수여'; Note='원작: 장수가 같은 종류의 명품을 여러 개 들어도 능력치가 가장 큰 하나만 적용됩니다. 나머지는 묶여서 낭비됩니다. / 변경: 명품 칸을 6슬롯으로 정리해 슬롯마다 가장 강한 것 하나만 착용하고, 남는 것은 세력창고로 돌려보냅니다. 창고 명품은 소유자가 「세력창고」로 보입니다. 명품·관직 수여 화면을 편하게 바꿉니다. / 효과: 낭비되는 명품 없이 필요한 장수에게 나눠 줍니다. / 필요: 편의·게임성 기능 전체'}
    @{Group='convenience'; Section='personnel'; Key='recruit'; Default=1; Requires=''; Inherit=''; Tab='편의성'; Label='등용 보조 (등용 화면·자동 등용·결과 안내)'; Note='원작: 등용은 대상을 한 명씩 고르고, 될지 안 될지 화면에서 알기 어렵습니다. / 변경: 등용 화면에서 대상을 여러 명 고를 수 있습니다. 나머지 대상에는 군사가 추천하는 실행 장수만 보냅니다(군사가 반대하면 보내지 않습니다). 숨은 인물 경고가 실제 등용 가능 여부를 반영합니다. / 효과: 등용을 한 번에 여러 명 걸고, 될 사람만 보냅니다. / 필요: 편의·게임성 기능 전체'}
    @{Group='convenience'; Section='domestic'; Key='region_officers'; Default=1; Requires=''; Inherit=''; Tab='편의성'; Label='월드맵 지역담당관 초상화'; Note='원작: 월드맵에서는 지역담당관이 누구인지 보이지 않습니다. / 변경: 내 도시·지역 이름표에 담당관 얼굴을 띄웁니다. 빈자리는 빈 얼굴과 회색 테두리로 보입니다. / 효과: 담당관이 빈 지역을 한눈에 찾습니다. / 필요: 편의·게임성 기능 전체'}
    @{Group='convenience'; Section='domestic'; Key='region_officer_traits'; Default=1; Requires='domestic.region_officers'; Inherit=''; Tab='편의성'; Label='지역담당관 이름 옆 내정 관련 개성 표시'; Note='원작: 담당관의 내정 개성은 무장 정보를 열어야 보입니다. / 변경: 담당관 이름 옆에 내정에 도움이 되는 개성을 적습니다. / 효과: 누구를 어디에 둘지 바로 판단합니다. / 필요: 월드맵 지역담당관 초상화'}
    @{Group='convenience'; Section='extensions'; Key='battle_deaths'; Default=1; Requires=''; Inherit=''; Tab='편의성'; Label='AI 전사 연출·게임 기록'; Note='원작: 컴퓨터끼리 싸우다 장수가 죽어도 연출과 기록이 없습니다. / 변경: 그 전사를 원작 일러스트·대사로 보여 주고 게임 기록에 남깁니다. / 효과: 누가 어디서 죽었는지 압니다. / 필요: 편의·게임성 기능 전체 / 출처: 삼갤 통합패치(180.71·175.115 유동)'}
    @{Group='convenience'; Section='officer_ui'; Key='loyalty'; Default=1; Requires=''; Inherit=''; Tab='편의성'; Label='숨겨진 충성도 숫자 표시'; Note='원작: 충성도가 화면에는 모두 100으로 보입니다. 실제 값은 숨겨져 있습니다. / 변경: 숨겨진 실제 충성도를 숫자로 보여 줍니다. / 효과: 누가 흔들리는지 정확히 압니다. / 필요: 편의·게임성 기능 전체'}
    @{Group='convenience'; Section='officer_ui'; Key='damage_preview'; Default=1; Requires=''; Inherit=''; Tab='편의성'; Label='예상 피해량 표시 (칼 등급 대신)'; Note='원작: 적을 고르면 유불리가 칼 등급으로만 보입니다. / 변경: 양쪽이 한 번 교전에서 잃는 병사 수를 숫자로 보여 줍니다. 성·관문·시설의 내구 피해도 보입니다. / 효과: 싸우기 전에 손해를 가늠합니다. / 필요: 편의·게임성 기능 전체'}
    @{Group='convenience'; Section='extensions'; Key='tooltip_collab'; Default=1; Requires=''; Inherit=''; Tab='편의성'; Label='개성·전법 툴팁 + 콜라보 개성/전법 해금'; Note='원작: 개성·전법에 마우스를 올려도 설명이 없고, 콜라보 개성·전법은 잠겨 있습니다. / 변경: 마우스를 올리면 설명을 띄우고, 콜라보 개성·전법을 풉니다. / 효과: 개성·전법이 무슨 효과인지 바로 봅니다. / 필요: 편의·게임성 기능 전체 / 출처: 삼갤 통합패치(180.71·175.115 유동)'}
    @{Group='convenience'; Section='game_flow'; Key='speed_buttons'; Default=1; Requires=''; Inherit=''; Tab='편의성'; Label='진행 속도 버튼 >>>>(×4)·>>>>>(×8)'; Note='원작: 진행 속도는 >>>까지입니다. / 변경: >>>의 4배, 8배 버튼을 더합니다. / 효과: 턴이 훨씬 빨리 넘어갑니다. / 필요: 편의·게임성 기능 전체 / 주의: 화면 자료를 바꾸므로 게임을 끄고 저장/적용하세요.'}
    @{Group='convenience'; Section='game_flow'; Key='occupy_fast'; Default=1; Requires=''; Inherit=''; Tab='편의성'; Label='거점 자동점령 연출 단축 (원작의 약 1/4)'; Note='원작: 거점을 점령할 때마다 카메라 이동과 효과가 길게 나옵니다. / 변경: 연출을 원작의 약 1/4로 줄입니다. / 효과: 점령이 많은 턴이 빨리 지나갑니다. / 필요: 편의·게임성 기능 전체'}
    @{Group='convenience'; Section='game_flow'; Key='advisor_briefing'; Default=1; Requires=''; Inherit=''; Tab='편의성'; Label='군사의 열흘 보고'; Note='원작: 소식이 창으로 하나씩 떠서 매번 닫아야 합니다. / 변경: 지난 10일의 소식을 왼쪽 아래 군사 알림함에 모읍니다. 보고 창의 [수집 설정]에서 종류별(명품 발견, 인재 발견, 등용 결과, 명승지 발견, 포로, 일기토, 천시, 재해, 외교, 수입 등 16가지)로 알림함에 모을지 원작대로 볼지 게임 안에서 고릅니다. / 효과: 창을 닫느라 끊기지 않고 진행하면서, 보고 싶은 장면은 원작대로 봅니다. / 필요: 편의·게임성 기능 전체'}
    @{Group='convenience'; Section='game_flow'; Key='briefing16'; Default=0; Requires='game_flow.advisor_briefing'; Inherit=''; Tab='편의성'; Label='군사 보고: 등용·포박 장면은 원작대로'; Note='배경: 군사 보고는 등용 성공·포박 장면도 알림함으로 보냅니다. / 변경: 등용 성공·포박 장면은 원작 장면으로 보여 주고, 군사 초상화는 원작 얼굴 그림을 씁니다. 계략 결과 때 카메라가 대상 지역으로 날아가는 연출을 생략합니다. 알림은 15초 뜹니다. / 효과: 보고 싶은 장면은 보고, 카메라는 덜 흔들립니다. / 필요: 군사의 열흘 보고'}
    @{Group='convenience'; Section='game_flow'; Key='ambush'; Default=0; Requires='game_flow.advisor_briefing'; Inherit=''; Tab='편의성'; Label='매복기동 (군사 제안)'; Note='원작: 없는 기능입니다. / 변경: 매달 상순 5% 확률(지난 순보다 아군 지역을 잃을 때마다 +10%)로 군사가 매복을 제안합니다. 그 순 안에 수락하면 준비 1개가 쌓입니다(최대 2개). 금 1,000을 내고 출진 화면의 [군사제안수행]으로 장수를 지정하면, 그 부대는 적 영역에 닿은 날부터 60일(길어도 180일) 동안 컴퓨터의 목표 탐색에서 빠집니다. / pk의 입성컨이 돌아왔습니다. 성을 찍지 않아도 동작합니다. / 효과: 적 뒤로 돌아가 기습할 수 있습니다. / 필요: 군사의 열흘 보고'}
    @{Group='convenience'; Section='game_flow'; Key='destruction_ticket'; Default=1; Requires='game_flow.ambush'; Inherit=''; Tab='편의성'; Label='파괴공작 준비 (군사 제안)'; Note='원작: 계략 건물파괴는 남의 땅에서는 대부분 실패합니다. / 변경: 우리 땅과 맞닿은 지역에 적 시설이 있으면 매달 상순 20%(시설 하나마다 +5%, 최대 60%) 확률로 군사가 파괴공작 준비를 제안합니다. 매복기동과 같은 달에는 둘 중 하나만 제안합니다. 그 순 안에 수락하면 금 1,000을 내고 준비 1개가 쌓입니다(최대 2개). 우리 땅과 맞닿은 지역에 쓴 건물파괴가 원래 판정에서 실패하면 준비 하나를 써서 성공으로 바꿉니다. 스스로 성공한 계략에는 쓰지 않습니다. / 효과: 전선의 적 투석대·망루를 확실히 깎을 수 있습니다. / 필요: 매복기동 (군사 제안)'}
    @{Group='convenience'; Section='game_flow'; Key='caravan_stay'; Default=1; Requires=''; Inherit=''; Tab='편의성'; Label='교역 무장 소재 고정 (원래 도시에 남고 각자 도시로 귀환)'; Note='원작: 교역을 보낸 장수는 도시 명단에서 빠지고, 돌아올 때 한 도시로 몰립니다. / 변경: 교역 간 장수가 원래 도시 소속으로 남고, 끝나면 각자 자기 도시로 돌아옵니다. / 효과: 교역 뒤에 장수를 다시 옮길 필요가 없습니다. / 필요: 편의·게임성 기능 전체 / 출처: 삼갤 주딱'}
    @{Group='convenience'; Section='game_flow'; Key='auto_search'; Default=0; Requires=''; Inherit=''; Tab='편의성'; Label='탐색 위임 (화면 왼쪽 아래 버튼)'; Note='원작: 인재 탐색은 매 턴 직접 보내야 합니다. / 변경: 왼쪽 아래 버튼을 켜 두면, 군사가 "인재 > 탐색 > 자동탐색"에 정해 둔 조건으로 턴마다 한 번 탐색을 보냅니다. / 효과: 탐색을 잊지 않습니다. / 필요: 편의·게임성 기능 전체'}
    @{Group='convenience'; Section='game_flow'; Key='auto_reward'; Default=0; Requires=''; Inherit=''; Tab='편의성'; Label='포상 위임 (화면 왼쪽 아래 버튼)'; Note='원작: 포상은 장수마다 직접 줘야 합니다. / 변경: 왼쪽 아래 버튼을 켜고 충성도 기준을 넣으면, 군사가 기준 이하 장수(모든 군단)에게 턴마다 포상합니다. 금이 모자라면 충성이 낮은 장수부터 줍니다. / 효과: 충성도가 떨어져 장수를 잃는 일이 줄어듭니다. / 필요: 편의·게임성 기능 전체'}
    @{Group='convenience'; Section='officer_ui'; Key='stat_exp'; Default=1; Requires=''; Inherit=''; Tab='편의성'; Label='능력치 경험치 표시 (오각형 그래프 숫자 뒤 /N%)'; Note='원작: 능력치가 언제 오를지 보이지 않습니다. / 변경: 오각형 그래프의 능력치 숫자 뒤에 다음 성장까지의 %를 적습니다. / 효과: 누가 곧 성장하는지 압니다. / 필요: 편의·게임성 기능 전체 / 출처: 삼갤 주딱'}
    @{Group='convenience'; Section='officer_ui'; Key='dispatch_days'; Default=1; Requires=''; Inherit=''; Tab='편의성'; Label='파견 남은 일수 표시 (파견 목록에 귀환까지 N일)'; Note='원작: 파견 간 장수가 언제 오는지 보이지 않습니다. / 변경: 파견 목록에 귀환까지 남은 일수를 적습니다. / 효과: 장수가 돌아오는 날을 압니다. / 필요: 편의·게임성 기능 전체 / 출처: 삼갤 주딱'}
    @{Group='convenience'; Section='officer_ui'; Key='mediation_plus'; Default=1; Requires=''; Inherit=''; Tab='편의성'; Label='중개 확장 (의형제 3인, 일부다처, 이혼)'; Note='원작: 의형제는 두 사람까지, 혼인은 한 사람과만 됩니다. 이혼은 없습니다. / 변경: 의형제 3명, 일부다처, 이혼을 고를 수 있습니다. / 효과: 장수 관계를 더 자유롭게 짭니다. / 필요: 편의·게임성 기능 전체 / 출처: 삼갤 주딱'}
    @{Group='convenience'; Section='officer_ui'; Key='drag_learn'; Default=1; Requires=''; Inherit=''; Tab='편의성'; Label='전법서 습득 다중 선택 (여러 무장 × 여러 전법서 한 번에)'; Note='원작: 전법서는 한 명에게 한 권씩 가르칩니다. / 변경: 여러 장수와 여러 전법서를 한 번에 고릅니다. / 효과: 전법 가르치는 시간이 줄어듭니다. / 필요: 편의·게임성 기능 전체 / 출처: 삼갤 주딱'}
    @{Group='convenience'; Section='officer_ui'; Key='drag_learn_multi'; Default=0; Requires='officer_ui.drag_learn'; Inherit=''; Tab='편의성'; Label='학습 창 여러 명 표시'; Note='배경: 위 다중 선택은 확인 창에 한 명만 보입니다. / 변경: 확인 창에 "외 N명"과 전법서·명령서 합계를 보여 줍니다. 전법서 재고 계산도 여러 명 기준으로 맞춥니다. / 효과: 한 번에 얼마나 쓰는지 확인하고 누릅니다. / 필요: 전법서 습득 다중 선택'}
    @{Group='convenience'; Section='officer_ui'; Key='lord_change'; Default=1; Requires=''; Inherit=''; Tab='편의성'; Label='시작 전 군주 변경 (세력 선택 하단 「반란」 버튼)'; Note='원작: 세력의 군주는 시나리오에 정해져 있습니다. / 변경: 세력 선택 화면 아래의 「반란」 버튼으로 시작 전에 군주를 바꿉니다. / 효과: 원하는 장수를 군주로 시작합니다. / 필요: 편의·게임성 기능 전체 / 출처: 삼갤 주딱'}
    @{Group='convenience'; Section='officer_ui'; Key='tactic_priority'; Default=1; Requires=''; Inherit=''; Tab='편의성'; Label='출진 화면 전법 우선순위·출진 기억'; Note='원작: 출진할 때마다 장수별로 전법과 진형을 다시 골라야 합니다. / 변경: 출진 화면의 「전법 우선순위」 버튼으로 전법 순서를 미리 정합니다(무력형·지력형 따로). 출진할 때 이 공통 규칙이 먼저 적용됩니다. 「출진 기억」을 켠 장수는 공통 규칙을 무시하고, 지난번 출진 때 쓴 전법과 진형을 그대로 씁니다. / 효과: 출진 준비가 빨라지고, 아끼는 장수는 늘 쓰던 구성으로 나갑니다. / 필요: 편의·게임성 기능 전체'}
    @{Group='convenience'; Section='extensions'; Key='scenery_skip'; Default=1; Requires=''; Inherit=''; Tab='편의성'; Retired=$true; Label='명승지 연출 생략'; Note='군사의 열흘 보고의 [수집 설정] → 「명승지 발견」으로 합쳤습니다. 알림함으로 두면 연출을 건너뛰고, 원작대로로 바꾸면 연출이 나옵니다. / 출처: 112.151 유동(삼봉이정도전)의 「11종 선택패치」'}
    @{Group='convenience'; Section='officer_ui'; Key='unified'; Default=0; Requires=''; Inherit=''; Tab='편의성'; Retired=$true; Label='통합 인사·무장 검색·출진 전법 자동 선택'; Note='개발 중지로 제거된 기능입니다.'}
    @{Group=''; Section='groups'; Key='performance'; Default=1; Requires=''; Inherit=''; Tab='게임렉제거(성능)'; Label='성능 가속 전체'; Note='변경: 이 탭의 가속 기능을 켭니다. / 효과: 끄면 이 탭이 모두 꺼집니다(빠른 자동저장은 편의 묶음 소속이라 따로입니다).'}
    @{Group='performance'; Section='performance'; Key='distance'; Default=1; Requires=''; Inherit=''; Tab='게임렉제거(성능)'; Label='거리·AI 진입 계산 가속'; Note='원작: AI가 칸 사이 거리를 잴 때마다 같은 계산을 되풀이합니다. / 변경: 같은 결과를 표에서 바로 꺼냅니다. / 효과: "전략중" 시간이 줄어듭니다. / 필요: 성능 가속 전체'}
    @{Group='performance'; Section='performance'; Key='name_lookup'; Default=1; Requires=''; Inherit=''; Tab='게임렉제거(성능)'; Label='원작 이름 탐색 가속'; Note='원작: 이름을 찾을 때마다 목록을 처음부터 뒤집니다. / 변경: 찾은 결과를 기억해 둡니다. / 효과: 목록 화면과 로딩이 덜 버벅입니다. / 필요: 성능 가속 전체'}
    @{Group='performance'; Section='performance'; Key='layout_keep'; Default=1; Requires=''; Inherit=''; Tab='게임렉제거(성능)'; Label='화면 레이아웃 보관 (턴 전환 로딩 단축)'; Note='원작: 턴이 바뀔 때마다 같은 화면을 새로 읽어 만듭니다. / 변경: 읽는 데 오래 걸린 화면을 메모리에 남겨 다시 씁니다. / 효과: 턴 전환 로딩이 짧아집니다. / 필요: 성능 가속 전체'}
    @{Group='performance'; Section='performance'; Key='fast_menu'; Default=1; Requires=''; Inherit=''; Tab='게임렉제거(성능)'; Label='지도 메뉴 클릭 대기 감소 (메뉴를 닫은 뒤 바로 다음 클릭)'; Note='원작: 지도 메뉴를 닫은 뒤 잠깐 클릭이 안 먹힙니다. / 변경: 그 대기를 줄입니다. / 효과: 메뉴를 닫고 바로 다음 클릭을 합니다. / 필요: 성능 가속 전체'}
    @{Group='performance'; Section='performance'; Key='appear_batch'; Default=1; Requires=''; Inherit=''; Tab='게임렉제거(성능)'; Label='부대 등장 묶음 처리 (전략중 뒤 0일 대기 단축)'; Note='원작: 출진 부대의 깃발과 정보 패널을 한 프레임에 하나씩 만듭니다. / 변경: 한 프레임에 여러 개를 만듭니다. / 효과: "전략중" 뒤 0일에서 멈춰 있는 시간이 줄어듭니다. / 필요: 성능 가속 전체'}
    @{Group='performance'; Section='performance'; Key='area_index'; Default=1; Requires=''; Inherit=''; Tab='게임렉제거(성능)'; Label='지역 칸 목록 캐시 (AI 건설 검사 가속)'; Note='원작: AI가 건설 자리를 볼 때마다 지도 전체(48,400칸)를 훑어 지역 시설 수를 셉니다. / 변경: 지역별 칸 목록을 미리 만들어 그 지역 칸만 셉니다. / 효과: "전략중" 시간이 줄어듭니다. / 필요: 성능 가속 전체'}
    @{Group='performance'; Section='performance'; Key='path_fast'; Default=1; Requires=''; Inherit=''; Tab='게임렉제거(성능)'; Label='경로 탐색 가속'; Note='원작: 부대 길 찾기가 다음 후보를 느린 방식으로 고르고, 같은 출발지에서 여러 목적지까지의 비용을 매번 처음부터 찾습니다. / 변경: 같은 길과 같은 비용을 더 적은 탐색으로 구합니다. / 효과: 군단이 많은 세력의 "전략중"이 크게 줄어듭니다. / 필요: 성능 가속 전체'}
    @{Group='performance'; Section='performance'; Key='face_keep'; Default=1; Requires=''; Inherit=''; Tab='게임렉제거(성능)'; Label='작은 무장 얼굴 상주 (깃발·선택·전략 화면)'; Note='원작: 깃발·선택 화면의 작은 얼굴 그림을 필요할 때마다 다시 읽습니다. / 변경: 읽은 얼굴을 메모리에 남겨 둡니다(최대 256명, 약 600MB 이하). / 효과: 화면을 열 때 얼굴이 바로 뜹니다. / 필요: 성능 가속 전체'}
    @{Group='performance'; Section='performance'; Key='face_prefetch'; Default=1; Requires='performance.face_keep'; Inherit=''; Tab='게임렉제거(성능)'; Label='출진 지휘관 얼굴 미리 요청 (0일 대기 단축)'; Note='원작: 부대가 나타날 때 얼굴을 하나씩 읽으며 한 프레임씩 기다립니다. / 변경: 나타나기 전에 한꺼번에 요청합니다. / 효과: 0일 대기가 더 줄어듭니다. / 필요: 작은 무장 얼굴 상주'}
    @{Group='performance'; Section='performance'; Key='timer_1ms'; Default=0; Requires=''; Inherit=''; Tab='게임렉제거(성능)'; Retired=$true; Label='1ms 타이머'; Note='측정상 효과가 없어 제거되었습니다.'}
    @{Group='convenience'; Section='game_flow'; Key='fast_save'; Default=1; Requires=''; Inherit=''; Tab='게임렉제거(성능)'; Label='빠른 자동저장 압축'; Note='원작: 자동저장 압축에 약 1.7초가 걸립니다. / 변경: 같은 형식으로 더 빠르게 압축하고, 풀어서 원본과 같은지 확인합니다. 다르면 원작 압축을 씁니다. / 효과: 자동저장이 약 0.1초로 줄어듭니다. / 필요: 편의·게임성 기능 전체(성능 묶음이 아닙니다)'}
    @{Group='performance'; Section='progress_native'; Key='geometry'; Default=1; Requires='performance.distance'; Inherit=''; Tab='게임렉제거(성능)'; Label='거리 계산 세부 가속'; Note='배경: 위 거리 가속의 세부 단계입니다. / 변경: 거리 가속 안의 기하 계산을 더 빠르게 합니다. / 효과: 거리 가속이 조금 더 빨라집니다. / 필요: 거리·AI 진입 계산 가속'}
    @{Group='convenience'; Section='stratagem'; Key='building_destruction_all'; Default=0; Requires=''; Inherit=''; Tab='게임성'; Label='건물파괴 지역 전체 피해'; Note='원작: 계략 「건물파괴」는 고른 지역의 적 건물 하나만 깎습니다. / 변경: 성공하면 그 지역의 모든 적 군사시설·장애물·함정에 같은 피해를 각각 줍니다(나눠 주지 않습니다). / 효과: 한 번에 지역의 적 시설을 쓸어냅니다. / 필요: 편의·게임성 기능 전체'}
    @{Group='convenience'; Section='stratagem'; Key='building_destruction_boost'; Default=1; Requires=''; Inherit=''; Tab='게임성'; Label='건물파괴 피해 1.5배'; Note='원작: 건물파괴 성공 피해는 원작 계산값입니다. / 변경: 성공 피해를 1.5배로 칩니다(원작 피해의 절반을 같은 건물에 한 번 더 적용). / 효과: 건물파괴가 더 쓸 만해집니다. / 필요: 편의·게임성 기능 전체'}
    @{Group=''; Section='groups'; Key='ccz'; Default=1; Requires=''; Inherit=''; Tab='조조전'; Label='조조전 기능 전체 (SAN14_CCZ.dll)'; Note='변경: 조조전 DLL을 불러와 이 탭 기능을 켭니다. / 효과: 끄면 이 탭이 모두 꺼집니다. / 필요: 편의·게임성 기능 전체'}
    @{Group='ccz'; Section='ccz'; Key='ccz_sprites'; Default=1; Requires=''; Inherit=''; Tab='조조전'; Label='조조전 병종 그림 (필드 부대)'; Note='원작: 필드 부대는 3D 모형으로 보입니다. / 변경: 조조전 병종 그림으로 바꿉니다. 옷은 세력색으로 칠하고, 이동·공격·대기 동작과 방향이 바뀝니다. 신조조전 장수 92명은 고유 그림을 씁니다. 3D 모형은 숨깁니다. / 효과: 조조전 느낌의 전장이 됩니다. / 필요: 조조전 기능 전체 / 그림 출처: 조조전(KOEI) 6.6·신조조전 7.0.'}
    @{Group='ccz'; Section='ccz'; Key='sprite_fallback'; Default=0; Requires='ccz.ccz_sprites'; Inherit=''; Tab='조조전'; Label='그림을 못 읽으면 원작 모델'; Note='배경: 그림을 못 읽거나 그림 칸이 모자라면 부대가 안 보일 수 있습니다. / 변경: 그럴 때 원작 3D 모형을 보여 줍니다. / 효과: 부대가 안 보이는 일이 없습니다. / 필요: 조조전 병종 그림'}
    @{Group='ccz'; Section='ccz'; Key='ccz_hide_model'; Default=0; Requires='ccz.ccz_sprites'; Inherit=''; Tab='조조전'; Retired=$true; Label='조조전 그림 부대의 원래 3D 모형 숨김'; Note='병종 그림에 통합되었습니다.'}
    @{Group='ccz'; Section='ccz'; Key='ccz_depth'; Default=0; Requires='ccz.ccz_sprites'; Inherit=''; Tab='조조전'; Retired=$true; Label='조조전 그림 지형 가림 처리'; Note='병종 그림에 통합되었습니다.'}
    @{Group='ccz'; Section='ccz'; Key='ccz_far_keep'; Default=0; Requires='ccz.ccz_sprites'; Inherit=''; Tab='조조전'; Retired=$true; Label='원거리 부대 그림 유지'; Note='더 이상 필요 없어 제거되었습니다.'}
    @{Group='ccz'; Section='ccz'; Key='ccz_block'; Default=1; Requires=''; Inherit=''; Tab='조조전'; Label='조조전식 막기'; Note='원작: 일반 공격은 늘 피해를 줍니다. / 변경: 맞는 장수의 무력이 높을수록, 1~10% 확률(5% + 무력 차 × 0.4)로 일반 공격을 완전히 막아 1명만 잃습니다. 한 번 터지면 그 공격을 포함해 5번을 막습니다. / 효과: 무력 높은 장수가 가끔 공격을 튕겨 냅니다. / 필요: 조조전 기능 전체'}
    @{Group='ccz'; Section='ccz'; Key='ccz_critical'; Default=1; Requires=''; Inherit=''; Tab='조조전'; Label='조조전식 회심의 일격'; Note='원작: 일반 공격 피해는 늘 같은 계산입니다. / 변경: 공격 장수의 무력과 부대 사기가 높을수록, 1~10% 확률(5% + 무력 차 × 0.3 + 사기 차 × 0.2)로 일반 공격 피해가 1.5배가 됩니다. 한 번 터지면 그 공격을 포함해 5번이 회심입니다. / 효과: 무력 높은 장수가 가끔 크게 때립니다. / 필요: 조조전 기능 전체'}
    @{Group='convenience'; Section='combat'; Key='district_intercept_block'; Default=1; Requires=''; Inherit=''; Tab='게임성'; Label='위임 군단 방침 지키기 (지원·내정은 출진 제한)'; Note='원작: 위임 군단의 방침은 성 공격을 허용할지에만 쓰입니다. 그래서 지원·내정 방침으로 맡긴 군단도 요격·방어·지역 점령 출진을 내보냅니다. / 변경: 지원 방침은 수송 출진만, 내정 방침은 수송·건설만 허용합니다. 요격을 못 해 수송이 영영 막히는 일이 없도록, 이 군단들은 "15칸 안에 적이 있으면 수송 안 함" 조건도 풉니다. / 효과: 위임 군단이 정해 준 방침대로만 움직입니다.'}
    @{Group='combat'; Section='combat'; Key='attack_eval70'; Default=0; Requires=''; Inherit=''; Tab='전투'; Label='공격 검토: 목표 성 전투력 70%'; Note='원작: 컴퓨터가 목표 성의 전투력을 100%로 보고 공격할지 정합니다. / 변경: 목표 성 전투력을 70%로 낮춰 봅니다. / 효과: 컴퓨터가 더 쉽게 공격을 결심합니다. / 필요: 전투 AI 교정 전체'}
    @{Group='combat'; Section='combat'; Key='retreat_eval60'; Default=0; Requires=''; Inherit=''; Tab='전투'; Label='야전 퇴각 재판정: 적 60%'; Note='원작: 야전 부대가 적 전투력을 100%로 보고 물러날지 정합니다. / 변경: 적을 60%로 낮춰 봅니다. / 효과: 컴퓨터 야전 부대가 덜 물러납니다. / 필요: 전투 AI 교정 전체'}
    @{Group='combat'; Section='combat'; Key='siege_guard'; Default=0; Requires=''; Inherit=''; Tab='전투'; Label='공성군 호위 요격 (모드 공성 군세 보강)'; Note='원작: 부대의 "적 접근 시 공격" 설정이 켜져 있을 때만 3칸 안의 적에 달려듭니다. 컴퓨터 공성 부대는 이 설정이 꺼진 채 나옵니다. / 배경: 모드가 공성 군세를 짜서 보내기 때문에, 그 군세가 옆을 지나는 플레이어 부대를 그냥 두는 문제를 보강하는 항목입니다. / 변경: 성 공략 군세의 야전 부대 중 지휘관 지력 80 이상인 부대는 정한 거리(기본 8칸) 안의 플레이어 부대를 요격합니다. / 효과: 공성군 옆을 지나가거나 뒤를 치기 어려워집니다. / 필요: 전투 AI 교정 전체'}
    @{Group='combat'; Section='combat'; Key='siege_guard_range'; Default=2; Requires='combat.siege_guard'; Inherit=''; Tab='전투'; Label='공성군 호위 요격 거리 (6~12칸)'; Note='배경: 공성군 호위 요격은 지휘관 지력 80 이상인 공성군 야전 부대가 가까운 플레이어 부대를 요격하는 기능입니다. / 변경: 요격하는 거리를 6 / 8 / 10 / 12칸 중에서 고릅니다(기본 8칸). / 효과: 거리가 멀수록 공성군 근처를 지나가기 어려워집니다. / 필요: 공성군 호위 요격'}
    @{Group='convenience'; Section='personnel'; Key='merit'; Default=1; Requires=''; Inherit=''; Tab='게임성'; Label='논공 확장 (아래 논공 항목의 묶음)'; Note='원작: 논공 단계마다 정해진 보상만 줍니다(무공 1·2단계는 지휘 병력, 3단계는 시정 Lv+1). / 변경: 아래 논공 항목(병력 보상 변경, 군주 친애)을 쓸 수 있게 합니다. 무공(지휘 병력)과 문공(담당 구역)은 한 장수가 한쪽만 받습니다. / 효과: 끄면 아래 논공 항목이 모두 꺼집니다. / 필요: 편의·게임성 기능 전체'}
    @{Group='convenience'; Section='personnel'; Key='merit_bond16'; Default=0; Requires='personnel.merit'; Inherit=''; Tab='게임성'; Label='논공 친애를 군주 가족까지'; Note='배경: 위 논공 친애는 군주 한 사람과만 맺어집니다. / 변경: 군주의 부모·배우자·의형제와도 친애가 됩니다. 이 경우 3단계 보상 표시는 "논공친애"가 되고 시정 Lv+1은 빠집니다. / 효과: 공을 세운 장수가 군주 일가 전체와 가까워집니다. / 필요: 논공 확장'}
    @{Group='convenience'; Section='personnel'; Key='merit_troops_level'; Default=4; Requires='personnel.merit'; Inherit=''; Tab='게임성'; Label='무공 1·2단계 병력 (1500~3000)'; Note='원작: 무공 1·2단계마다 지휘 병력이 500(새 패치 1,000) 늘어납니다. / 변경: 늘어나는 병력을 1,500 / 2,000 / 2,500 / 3,000 중에서 고릅니다. / 효과: 공을 세운 장수가 더 큰 부대를 이끕니다. / 필요: 논공 확장'}
    @{Group='convenience'; Section='personnel'; Key='merit_friendship'; Default=1; Requires='personnel.merit'; Inherit=''; Tab='게임성'; Label='논공 친애 (무공 3단계 군주 상호 친애)'; Note='원작: 무공 3단계 보상은 시정 Lv+1입니다. / 변경: 시정 Lv+1은 그대로 두고, 그 장수와 군주가 서로 친애가 됩니다. / 효과: 공을 많이 세운 장수가 군주와 함께 싸울 때 친애 효과를 받습니다. / 필요: 논공 확장'}
    @{Group='convenience'; Section='personnel'; Key='awards_ai'; Default=1; Requires='personnel.awards'; Inherit=''; Tab='게임성'; Label='컴퓨터 명품 자동 배분'; Note='원작: 컴퓨터는 군주가 보물을 잔뜩 들고 있고, 정작 쓸 장수에게는 가지 않습니다. / 변경: 컴퓨터 세력이 창고의 명품을 능력치가 맞는 장수에게 슬롯별로 나눠 줍니다. 군주가 착용한 것은 건드리지 않습니다. / 효과: 컴퓨터 장수들이 제 몫의 명품을 들고 나옵니다. / 필요: 명품창고·6슬롯'}
    @{Group='convenience'; Section='personnel'; Key='awards_horse'; Default=0; Requires='personnel.awards_ai'; Inherit=''; Tab='게임성'; Label='퇴각확실 명마 우선'; Note='배경: 위 자동 배분은 능력치 순으로 나눕니다. / 변경: 퇴각이 확실해지는 명마는 군주와 지정된 장수에게 먼저 줍니다. / 효과: 컴퓨터 군주를 붙잡기 어려워집니다. / 필요: 컴퓨터 명품 자동 배분'}
    @{Group='convenience'; Section='personnel'; Key='awards_v16'; Default=0; Requires='personnel.awards_ai'; Inherit=''; Tab='게임성'; Label='명품 배분에 명령서 안 씀'; Note='배경: 위 자동 배분도 원작처럼 명령서를 씁니다. / 변경: 컴퓨터의 자동 배분에 명령서를 쓰지 않습니다. / 효과: 컴퓨터가 명령서 부족으로 명품을 못 나누는 일이 없어집니다. / 필요: 컴퓨터 명품 자동 배분'}
    @{Group='convenience'; Section='personnel'; Key='recruit_ai'; Default=1; Requires=''; Inherit='personnel.recruit'; Tab='게임성'; Label='안 될 등용은 시도하지 않음 (컴퓨터·위임 군단)'; Note='원작: 군주를 싫어해서 절대 오지 않을 인물에게도 계속 사자를 보냅니다. / 변경: 성공할 수 없는 등용은 시도하지 않습니다. / 효과: 컴퓨터와 위임 군단이 명령서와 장수를 헛되이 쓰지 않습니다. / 필요: 편의·게임성 기능 전체'}
    @{Group='convenience'; Section='personnel'; Key='injury'; Default=1; Requires=''; Inherit=''; Tab='게임성'; Label='부상 무장 보호'; Note='원작: 컴퓨터가 부상한 장수도 출진·임무에 계속 써서 죽게 만듭니다. / 변경: 부상한 장수를 출진·수송·탐색·등용·훈련·첩보·유언비어 후보에서 뺍니다. / 효과: 컴퓨터 장수가 부상 때문에 덜 죽습니다. / 필요: 편의·게임성 기능 전체'}
    @{Group='convenience'; Section='personnel'; Key='injury_herbal'; Default=1; Requires=''; Inherit='personnel.injury'; Tab='게임성'; Label='컴퓨터 세력 본초학 시정 자동 배치'; Note='원작: 컴퓨터는 부상자가 있어도 본초학 시정을 일부러 넣지 않습니다. / 변경: 부상자가 있는 컴퓨터 세력은 시정 계획에 본초학을 넣습니다. / 효과: 컴퓨터 장수의 부상이 빨리 낫습니다. / 필요: 편의·게임성 기능 전체'}
    @{Group='convenience'; Section='personnel'; Key='ai_search2'; Default=1; Requires=''; Inherit=''; Tab='게임성'; Label='컴퓨터 군단 2차 탐색 생략'; Note='원작: 컴퓨터 군단이 한 턴에 인재 탐색을 두 번 돌립니다. 두 번째는 대기 장수 거의 전원을 이미 다 찾은 자기 지역에 보냅니다. / 변경: 쓸모없는 두 번째 탐색을 하지 않습니다. / 효과: 턴 진행이 빨라지고, 컴퓨터 장수가 헛일에 묶이지 않습니다. / 필요: 편의·게임성 기능 전체 / 출처: 삼갤 주딱 (SAN14_AISearch v1.1)'}
    @{Group='convenience'; Section='personnel'; Key='ai_learn'; Default=1; Requires='personnel.ai_search2'; Inherit=''; Tab='게임성'; Label='컴퓨터 군단 2차 탐색 대신 전법 습득'; Note='원작: 컴퓨터 군단은 남는 명령서를 두 번째 탐색에 씁니다(2차 탐색 생략이 켜져 있으면 그냥 남습니다). 전법 습득은 빈칸이 있을 때만 가끔 합니다. / 변경: 2차 탐색을 거른 컴퓨터 군단 무장(플레이어 직할·위임 군단 제외)이 그 명령서로 원작 습득 함수를 써서 세력 서고의 전법서 하나를 배웁니다(전법서 1권·명령서 1장, 세력 주의 경험치 획득은 원작과 같음). 고를 전법 순서: 고유전법 > 교역전법(아수라진·구갑대열·안식사법) > 다른 이민족 전법 > 무력형(무력≥지력) 연노·매성·도발·혼란·급습·분전·저지·돌격·대갈·제사·경파, 지력형 매성·혼란·업화·화시·도발·저지·대갈, 그 뒤 나머지. 전법이 10개면 가장 낮은 전법을 지우고 배웁니다. 고유전법과 수상 전법(구축·강습·시람)은 한 번 배우면 지우지 않고, 위 목록 뒤의 ''나머지'' 전법끼리는 계속 지우고 다시 배워 경험치를 쌓습니다. 세력의 주의(시정) Lv이 10(최대)이면 전법 10개를 다 배운 무장은 더 배우지 않고, 덜 배운 무장만 배웁니다. / 효과: 컴퓨터 세력의 주의(시정) 단계가 빨리 오릅니다. / 필요: 컴퓨터 군단 2차 탐색 생략'}
    @{Group='convenience'; Section='personnel'; Key='officer_first'; Default=1; Requires=''; Inherit=''; Tab='게임성'; Label='컴퓨터 군단 모병·훈련 담당관 매 턴 검토'; Note='원작: 플레이어의 도시 점유율이 30% 미만이면, 컴퓨터는 모병·훈련 담당관 임명을 난이도에 따라 3턴에 1~2번만 검토합니다. / 변경: 매 턴 검토합니다. / 효과: 컴퓨터가 초반부터 병력을 꾸준히 모읍니다. / 필요: 편의·게임성 기능 전체'}
    @{Group='convenience'; Section='personnel'; Key='officer_rotation'; Default=1; Requires=''; Inherit=''; Tab='게임성'; Label='컴퓨터가 좋은 장수를 전선으로 (매월 상순)'; Note='원작: 컴퓨터의 통솔 높은 장수가 후방 도시에 남아 있기도 합니다. / 변경: 매월 상순 한 번, 전선 도시의 통솔 낮은 장수와 후방 도시의 통솔 높은 장수를 최대 4쌍 맞바꿉니다. 전선 도시 = 적대 세력 지역과 맞닿은 도시(동맹·정전·속국은 전선이 아님). 친애인 장수끼리 같은 도시에 모이도록, 범위 개성 장수가 전선에 가도록 짝을 고릅니다. 한 번 옮긴 장수는 3개월 동안 다시 옮기지 않습니다. 군주는 움직이지 않습니다. / 효과: 전선에서 만나는 컴퓨터 장수가 강해지고, 친애 조합이 자주 나옵니다. / 필요: 편의·게임성 기능 전체'}
    @{Group='convenience'; Section='domestic'; Key='domestic'; Default=1; Requires=''; Inherit=''; Tab='게임성'; Label='자동 내정 (낮은 개발부터 고르게)'; Note='원작: 컴퓨터와 위임 군단은 상업을 5레벨까지 올리면 그 지역 개발을 더 하지 않습니다. / 변경: 상업·농업·병영 중 가장 낮은 것을 골라 올립니다(최대치는 제외, 같으면 상업 → 농업 → 병영). 이미 임명된 담당관의 개발 항목도 매일 다시 맞춥니다. / 효과: 위임한 지역과 컴퓨터 지역이 끝까지 고르게 발전합니다. / 필요: 편의·게임성 기능 전체'}
    @{Group='convenience'; Section='domestic'; Key='domestic_direct'; Default=0; Requires='domestic.domestic'; Inherit=''; Tab='게임성'; Label='1군단(군주 직할) 자동 내정'; Note='원작: 1군단 지역은 플레이어가 직접 개발 항목을 정합니다. / 변경: 1군단 지역도 매일 균형 개발 항목으로 바꿉니다. / 효과: 직접 내정을 안 해도 됩니다. / 필요: 자동 내정 / 주의: 내가 정한 개발 항목을 덮어씁니다.'}
    @{Group='convenience'; Section='domestic'; Key='domestic_free'; Default=1; Requires='domestic.domestic'; Inherit=''; Tab='게임성'; Label='지역담당관 자동 임명 명령서 비용 0'; Note='원작: 지역담당관을 임명할 때마다 명령서가 듭니다. / 변경: 위임 군단과 컴퓨터의 자동 임명은 명령서를 쓰지 않습니다. / 효과: 위임 군단이 명령서 부족으로 담당관을 비워 두지 않습니다. / 필요: 자동 내정'}
    @{Group='convenience'; Section='domestic'; Key='population'; Default=1; Requires=''; Inherit=''; Tab='게임성'; Label='인구 월간 증가 배율'; Note='원작: 인구가 매달 원작 속도로 늡니다. / 변경: 매달 늘어나는 인구(늘어날 때만)에 아래 배율을 곱합니다. / 효과: 인구가 빨리 늡니다. / 필요: 편의·게임성 기능 전체'}
    @{Group='convenience'; Section='domestic'; Key='population_rate'; Default=4; Requires='domestic.population'; Inherit=''; Tab='게임성'; Label='인구 증가 배율 (1~4배)'; Note='원작: 1배. / 변경: 1~4배 중에서 고릅니다. / 효과: 숫자가 클수록 인구가 빨리 늡니다. / 필요: 인구 월간 증가 배율'}
    @{Group='convenience'; Section='extensions'; Key='traits9'; Default=1; Requires=''; Inherit=''; Tab='게임성'; Label='개성 9칸'; Note='원작: 세이브에는 개성 칸이 9개 있지만 게임은 5칸만 씁니다. / 변경: 판정·선택·무장 상세·일람에서 9칸 모두 씁니다. / 효과: 한 장수가 개성을 9개까지 가집니다. / 필요: 편의·게임성 기능 전체'}
    @{Group='convenience'; Section='extensions'; Key='stats200'; Default=1; Requires=''; Inherit=''; Tab='게임성'; Label='능력치 상한 200'; Note='원작: 능력치 상한은 100입니다. / 변경: 상한을 200으로 올립니다. / 효과: 100을 넘는 성장과 명품·개성 보정이 그대로 반영됩니다. / 필요: 편의·게임성 기능 전체'}
    @{Group='convenience'; Section='extensions'; Key='stats200_growth'; Default=1; Requires='extensions.stats200'; Inherit=''; Tab='게임성'; Label='능력치 100 이후 자연 성장'; Note='원작: 능력치 100에서 경험치 성장이 멈춥니다. / 변경: 100을 넘어서도 경험치로 조금씩 자랍니다(200까지). / 효과: 오래 쓴 장수가 계속 강해집니다. / 필요: 능력치 상한 200'}
    @{Group=''; Section='groups'; Key='diagnostics'; Default=0; Requires=''; Inherit=''; Tab='기타(개발용)'; Label='개발용 기능 전체'; Note='용도: 아래 기록·측정 항목의 묶음 / 주의: 일반 플레이에는 필요 없음'}
    @{Group='diagnostics'; Section='diagnostics'; Key='enabled'; Default=0; Requires=''; Inherit=''; Tab='기타(개발용)'; Label='진단 로그 기록 (SAN14_*.log)'; Note='용도: 모드 판단과 오류를 게임 폴더 로그에 남김 / 필요: 개발용 기능 전체 / 주의: 배포용 DLL에서는 효과 없음'}
    @{Group='diagnostics'; Section='diagnostics'; Key='terrain_diag_mode'; Default=0; Requires=''; Inherit=''; Tab='기타(개발용)'; Label='지형 편집 렉 분리 A/B/C'; Note='용도: 지형 편집 렉 원인을 나눠 봅니다. 0=기준(물살·렌더러 ON), 1=A(물살 OFF), 2=B(렌더러·높이 캡처 OFF), 3=C(둘 다 OFF). / 필요: 개발용 기능 전체 / 주의: A/B/C는 진단 전용입니다. terrain_edit=1에서 줌 렉 비교만 하고 실제 지형 편집·저장에는 사용하지 마세요.'}
    @{Group='diagnostics'; Section='diagnostics'; Key='season_probe'; Default=0; Requires=''; Inherit=''; Tab='기타(개발용)'; Label='4계절 탐침 (G0)'; Note='용도: 4계절 패치 설계용. 1=텍스처·셰이더 생성 기록, 2=셰이더 덤프(data/diagnostics/season_probe), 4=큰 텍스처에 색 띠 표시, 8=지도 텍스처 원본 저장(굽기 시험용). 더해서 씁니다. / 필요: 개발용 기능 전체 / 주의: 진단 전용. 7이면 땅·건물에 색 띠가 보입니다. 확인 후 0으로 돌리세요. 배포용 DLL에서는 효과 없음.'}
    @{Group=''; Section='groups'; Key='modpack'; Default=1; Requires=''; Inherit=''; Tab='180(wprkfdid12-ux) 모드팩 호환'; Label='180 모드팩 호환 전체 (SAN14_ModPack.dll)'; Note='변경: 다른 모더의 패치(4계절 패치, wprkfdid12-ux)를 이 모드 방식으로 옮긴 기능을 켭니다. / 효과: 끄면 이 탭이 모두 꺼지고 원작 그대로입니다. / 필요: 편의·게임성 기능 전체'}
    @{Group='modpack'; Section='season'; Key='season_map'; Default=0; Requires=''; Inherit=''; Tab='180(wprkfdid12-ux) 모드팩 호환'; Label='4계절 지도 색'; Note='용도: 땅 지도 색을 계절과 순(상순·중순·하순)에 맞춰 바꿉니다(봄 연두, 여름 짙은 녹색, 가을 단풍, 겨울 눈). / 출처: 4계절 패치 (wprkfdid12-ux) / 주의: 0이면 원작 지도 색.'}
    @{Group='modpack'; Section='season'; Key='season_weather'; Default=0; Requires='season.season_map'; Inherit=''; Tab='180(wprkfdid12-ux) 모드팩 호환'; Label='4계절 날씨·재해 규칙'; Note='용도: 날씨와 강 결빙, 홍수를 지도 칸마다 굴립니다. 대하가 얼고, 장안 14칸 안의 위수(강)도 가장 가까운 대하가 얼 때 함께 얼어붙습니다. 눈 쌓인 칸에서는 부대 기동 -1, 얼음 위에서는 기동 -3이고, 사기는 깎지 않습니다. 플레이어와 컴퓨터에 똑같이 적용됩니다. / 필요: 4계절 지도 색 / 출처: 4계절 패치 (wprkfdid12-ux)'}
    @{Group='modpack'; Section='season'; Key='season_disaster'; Default=1; Requires='season.season_weather'; Inherit=''; Tab='180(wprkfdid12-ux) 모드팩 호환'; Label='4계절 재해'; Note='용도: 장강·한수·황하와 하비·여강·소호(합비·역양의 호수와 습지)·무릉·영릉·강주·건녕 부근 강의 홍수만 일어납니다(횟수 제한 없음, 강물이 둑을 넘을 때마다). 여강과 소호는 둑이 낮아 폭우에 더 자주 넘칩니다. 물에 잠긴 평지·가도·모래·습지는 물이 찰 동안 여울·강 지형이 되고, 물이 빠지면 원래 땅으로 돌아갑니다. 산불·산사태·지진·가뭄 흉작은 없습니다. / 필요: 4계절 날씨·재해 규칙 / 주의: 0이면 날씨만 남고 재해는 없습니다.'}
    @{Group='modpack'; Section='season'; Key='season_damage'; Default=1; Requires='season.season_weather'; Inherit=''; Tab='180(wprkfdid12-ux) 모드팩 호환'; Label='4계절 피해 (병력·사기·내구)'; Note='용도: 예전 날씨·재해 피해(병력·사기·성벽 내구) 자리입니다. 지금은 깎는 규칙이 없습니다. / 필요: 4계절 날씨·재해 규칙 / 주의: 0이면 그림과 소식만 남고 피해는 없습니다.'}
    @{Group='modpack'; Section='season'; Key='season_news'; Default=1; Requires='season.season_weather'; Inherit=''; Tab='180(wprkfdid12-ux) 모드팩 호환'; Label='4계절 소식'; Note='용도: 재해·날씨 소식을 원작 소식 목록과 턴 보고(중요 탭)에 남깁니다. / 필요: 4계절 날씨·재해 규칙 / 주의: 0이면 소식 없이 조용히 진행됩니다.'}
    @{Group='modpack'; Section='season'; Key='season_fire'; Default=1; Requires='season.season_weather'; Inherit=''; Tab='180(wprkfdid12-ux) 모드팩 호환'; Retired=$true; Label='4계절 화계 확률'; Note='용도: 예전 날씨 화계 규칙 자리입니다. 지금은 쓰지 않고 원작 화계 그대로입니다. / 필요: 4계절 날씨·재해 규칙 / 주의: 0이면 원작 화계 확률.'}
    @{Group='modpack'; Section='season'; Key='season_domestic'; Default=1; Requires='season.season_weather'; Inherit=''; Tab='180(wprkfdid12-ux) 모드팩 호환'; Label='4계절 치안·인구'; Note='용도: 예전 재해의 치안·인구 변화 자리입니다. 지금은 바꾸는 규칙이 없습니다. / 필요: 4계절 날씨·재해 규칙 / 주의: 0이면 치안·인구는 그대로.'}
    @{Group='modpack'; Section='season'; Key='season_rain'; Default=1; Requires='season.season_weather'; Inherit=''; Tab='180(wprkfdid12-ux) 모드팩 호환'; Retired=$true; Label='4계절 비·눈 내리기'; Note='용도: 예전 빗줄기·눈송이 화면 효과 자리입니다. 지금은 그리지 않습니다(4계절 지도 색의 계절 눈은 그대로). / 필요: 4계절 날씨·재해 규칙 / 주의: 0이면 원작 화면 그대로.'}
    @{Group='modpack'; Section='season'; Key='season_cloud'; Default=1; Requires='season.season_weather'; Inherit=''; Tab='180(wprkfdid12-ux) 모드팩 호환'; Label='4계절 원경 구름'; Note='용도: 4계절 패치(wprkfdid12-ux)의 비구름만 그립니다. 지도를 멀리서 볼 때 비가 오는 칸 위에 옅은 회백색 구름이 떠 있고, 가장 가까운 확대와 전체 지도(세력 색 지도)에서는 사라집니다. 빗줄기·물방울·비 안개·젖은 땅은 그리지 않습니다. / 필요: 4계절 날씨·재해 규칙 / 주의: 0이면 원작 화면 그대로.'}
    @{Group='modpack'; Section='season'; Key='season_tiles'; Default=1; Requires='season.season_weather'; Inherit=''; Tab='180(wprkfdid12-ux) 모드팩 호환'; Label='4계절 재해 타일'; Note='용도: 홍수가 난 평지·가도·모래·습지를 물이 찰 동안 여울·강 지형으로, 얼어붙은 대하를 새 지형 「결빙」(걸어서 건널 수 있고 이동 비용은 평지와 같으며 불이 붙지 않음)으로 바꾸고, 물이 빠지거나 얼음이 녹으면 원래 지형으로 되돌립니다. 지형이 바뀌거나 돌아올 때 그 칸의 시설(중립 포함, 도시·관문 제외)은 부서지고, 부대가 있어도 그대로 바뀝니다. 홍수 때 4계절 패치의 물 그림(하늘색 물결)은 따로 그리지 않고, 바뀐 강 지형만 보입니다. 물에 잠기는 칸은 단계마다 평지→습지→여울→강→대하로 한 칸씩 젖고(건물은 물이 될 때만 부서짐), 업(황하 여양항)·양양/번성(한수)·여강(장강)은 역사 속 수몰처럼 홍수가 더 쉽게 나고 잠기는 땅이 넓으며 강이 첫 단계부터 대하로 불어납니다. 물이 오른 단계는 1단계 1순·2단계 2순·3단계 3순 동안 그대로 머문 뒤 3일마다 한 단계씩 빠집니다. / 필요: 4계절 날씨·재해 규칙, 부동산 개발(지형 편집) / 주의: 0이면 땅 그림은 원작 그대로.'}
    @{Group='diagnostics'; Section='diagnostics'; Key='reuse_handle'; Default=0; Requires=''; Inherit=''; Tab='기타(개발용)'; Label='로그 파일 핸들 재사용'; Note='용도: 로그 기록 비용을 줄임 / 필요: 개발용 기능 전체'}
    @{Group='diagnostics'; Section='diagnostics'; Key='ai_trace'; Default=0; Requires=''; Inherit=''; Tab='기타(개발용)'; Label='원작 AI 행동 추적 (CSV)'; Note='용도: 원작 AI가 목표를 바꾸는 과정을 기록 / 필요: 개발용 기능 전체 / 주의: 기록량이 많음'}
    @{Group='diagnostics'; Section='diagnostics'; Key='ai_trace_original'; Default=0; Requires='diagnostics.ai_trace'; Inherit=''; Tab='기타(개발용)'; Label='원작만 추적 (모드 훅 연결 안 함)'; Note='용도: 모드를 연결하지 않고 원작 AI만 기록 / 필요: 원작 AI 행동 추적 / 주의: 이 상태로 기존 세이브에 덮어쓰지 말 것'}
    @{Group='diagnostics'; Section='diagnostics'; Key='layout_wait'; Default=0; Requires=''; Inherit=''; Tab='기타(개발용)'; Label='화면 레이아웃 대기 기록'; Note='용도: 턴 전환 로딩 시간을 기록 / 필요: 개발용 기능 전체'}
    @{Group='diagnostics'; Section='diagnostics'; Key='day_stage'; Default=0; Requires=''; Inherit=''; Tab='기타(개발용)'; Label='하루 처리 단계 기록'; Note='용도: 하루 처리 단계별 시간을 기록 / 필요: 개발용 기능 전체 + 진행 속도 버튼'}
    @{Group='diagnostics'; Section='diagnostics'; Key='cost_profile'; Default=0; Requires=''; Inherit=''; Tab='기타(개발용)'; Label='함수 시간 측정 (CSV)'; Note='용도: 함수별 호출 수·시간을 기록 / 필요: 개발용 기능 전체 / 주의: 측정 중 조금 느려짐'}
    @{Group='diagnostics'; Section='diagnostics'; Key='call_trace'; Default=0; Requires=''; Inherit=''; Tab='기타(개발용)'; Label='함수 호출 추적 (개발용)'; Note='용도: 크래시 기록에 호출 흐름을 남김 / 필요: 개발용 기능 전체 / 주의: 게임이 느려짐'}
    @{Group='diagnostics'; Section='diagnostics'; Key='area_index_verify'; Default=0; Requires=''; Inherit=''; Tab='기타(개발용)'; Label='지역 칸 캐시 원작 결과 대조'; Note='용도: 캐시 결과를 원작과 대조 / 필요: 개발용 기능 전체 + 지역 칸 캐시 / 주의: 측정 중 느려짐'}
    @{Group='diagnostics'; Section='diagnostics'; Key='path_fast_verify'; Default=0; Requires=''; Inherit=''; Tab='기타(개발용)'; Label='경로 탐색 가속 결과 비교'; Note='용도: 가속 결과를 원작과 대조 (0=끔, 1=매번, N=N번에 한 번) / 필요: 개발용 기능 전체 + 경로 탐색 가속 / 주의: 측정 중 느려짐'}
    @{Group='diagnostics'; Section='diagnostics'; Key='path_count'; Default=0; Requires=''; Inherit=''; Tab='기타(개발용)'; Label='경로 탐색 호출 횟수 기록'; Note='용도: 경로 탐색 호출 횟수를 기록 / 필요: 개발용 기능 전체 + 함수 시간 측정 / 주의: 경로 탐색 가속이 켜져 있으면 기록하지 않음'}
    @{Group='diagnostics'; Section='diagnostics'; Key='water_diag'; Default=0; Requires=''; Inherit=''; Tab='기타(개발용)'; Label='물살 렌더 진단'; Note='용도: 물살 처리 과정을 기록 / 필요: 개발용 기능 전체 / 주의: 관찰 전용'}
    @{Group='diagnostics'; Section='diagnostics'; Key='gpu_profile'; Default=0; Requires=''; Inherit=''; Tab='기타(개발용)'; Label='GPU 시간 기록'; Note='용도: 그래픽 처리 시간을 기록 / 필요: 개발용 기능 전체 / 주의: 관찰 전용'}
    @{Group='diagnostics'; Section='progress_native'; Key='profile'; Default=0; Requires=''; Inherit=''; Tab='기타(개발용)'; Label='AI 진행 함수 시간 기록'; Note='용도: 원작 AI 진행 함수 시간을 기록 / 필요: 개발용 기능 전체'}
)
function Read-FeatureIni([string]$Path) {
    $taskIni = @{}
    if (-not [IO.File]::Exists($Path)) { return $taskIni }
    $taskSection = ''
    foreach ($taskLine in ([IO.File]::ReadAllText($Path) -split "`r?`n")) {
        $taskText = $taskLine.Trim()
        if ($taskText -match '^\[(.+)\]$') { $taskSection = $Matches[1].Trim().ToLowerInvariant(); if (-not $taskIni.ContainsKey($taskSection)) { $taskIni[$taskSection] = [ordered]@{} }; continue }
        if ($taskText -eq '' -or $taskText.StartsWith(';') -or $taskSection -eq '') { continue }
        $taskAt = $taskText.IndexOf('=')
        if ($taskAt -gt 0) { $taskIni[$taskSection][$taskText.Substring(0,$taskAt).Trim().ToLowerInvariant()] = $taskText.Substring($taskAt+1).Trim() }
    }
    return $taskIni
}
function Get-FeatureValues($Ini) {
    $taskValues = [ordered]@{}
    # Inheriting keys are resolved after the switches they fall back to.
    foreach ($taskItem in (@($taskFeatureCatalog | Where-Object { -not $_.Inherit }) + @($taskFeatureCatalog | Where-Object { $_.Inherit }))) {
        $taskValue = $taskItem.Default
        if ($taskItem.Inherit -and $taskValues.Contains($taskItem.Inherit)) { $taskValue = $taskValues[$taskItem.Inherit] }
        $taskSources=@(@('features',$taskItem.Key), @($taskItem.Section,$taskItem.Key))
        if($taskItem.Section -eq 'performance' -and $taskItem.Key -eq 'fast_menu'){$taskSources=@(@('game_flow','fast_menu'))+$taskSources}
        foreach ($taskSource in $taskSources) {
            if ($Ini.ContainsKey($taskSource[0]) -and $Ini[$taskSource[0]].Contains($taskSource[1])) {
                $taskNumber = 0
                if ([int]::TryParse($Ini[$taskSource[0]][$taskSource[1]], [ref]$taskNumber)) { $taskValue = if ($taskItem.Key -eq 'path_fast_verify') { [Math]::Max(0, $taskNumber) } elseif ($taskItem.Key -eq 'terrain_diag_mode') { [Math]::Max(0, [Math]::Min(3, $taskNumber)) } elseif ($taskItem.Key -eq 'population_rate' -or $taskItem.Key -eq 'merit_troops_level' -or $taskItem.Key -eq 'siege_guard_range') { [Math]::Max(1, [Math]::Min(4, $taskNumber)) } else { [int]($taskNumber -ne 0) } }
            }
        }
        $taskValues[$taskItem.Section + '.' + $taskItem.Key] = if ($taskItem.Retired) { 0 } else { $taskValue }
    }
    return $taskValues
}
function Write-FeatureIni([string]$Path, $Values, $Ini) {
    # user 2026-11-03: known obsolete keys only; preserve every unknown/raw key.
    if($Ini.Contains('game_flow')){$Ini['game_flow'].Remove('fast_menu')}
    if($Ini.Contains('performance')){$Ini['performance'].Remove('strategy_batch')}
    $taskLines = New-Object Collections.Generic.List[string]
    $taskLines.Add('; AI 모드 기능 켜기/끄기. 1 = 켜기, 0 = 끄기. 게임을 다시 시작하면 적용됩니다.')
    $taskLines.Add('; 관리 도구: optional_tools\AI모드_기능선택.cmd 또는 AI모드_적용.cmd 실행 중 선택 화면.')
    $taskLines.Add('; 함께 묶인 항목은 같은 게임 코드를 공유하므로 따로 끌 수 없습니다.')
    $taskSections = New-Object Collections.Generic.List[string]
    foreach ($taskItem in $taskFeatureCatalog) { if (-not $taskSections.Contains($taskItem.Section)) { $taskSections.Add($taskItem.Section) } }
    $taskOwned = @{}; foreach ($taskItem in $taskFeatureCatalog) { $taskOwned[$taskItem.Section + '.' + $taskItem.Key] = $true }
    foreach ($taskSection in $taskSections) {
        $taskLines.Add(''); $taskLines.Add('[' + $taskSection + ']')
        foreach ($taskItem in ($taskFeatureCatalog | Where-Object { $_.Section -eq $taskSection })) {
            $taskComment = '; ' + $taskItem.Label
            if ($taskItem.Note) { $taskComment += ' — ' + $taskItem.Note }
            $taskLines.Add($taskComment)
            if ($taskItem.Retired) { $Values[$taskItem.Section + '.' + $taskItem.Key] = 0 }
            $taskLines.Add($taskItem.Key + '=' + $Values[$taskItem.Section + '.' + $taskItem.Key])
        }
        # Hidden/newer keys of an owned section stay inside it: the DLL reads only the first
        # [section] of a name, so a second header would silently lose them (2026-11-01).
        if ($Ini.Contains($taskSection)) {
            foreach ($taskKey in @($Ini[$taskSection].Keys | Where-Object { -not $taskOwned.ContainsKey($taskSection + '.' + $_) })) { $taskLines.Add($taskKey + '=' + $Ini[$taskSection][$taskKey]) }
        }
    }
    # Sections the menu does not own (diagnostics, hidden keys) are kept as they were.
    foreach ($taskSection in $Ini.Keys) {
        if ($taskSection -eq 'features' -or $taskSections.Contains($taskSection)) { continue }
        $taskExtra = @($Ini[$taskSection].Keys | Where-Object { -not $taskOwned.ContainsKey($taskSection + '.' + $_) })
        if ($taskExtra.Count -eq 0) { continue }
        $taskLines.Add(''); $taskLines.Add('[' + $taskSection + ']')
        foreach ($taskKey in $taskExtra) { $taskLines.Add($taskKey + '=' + $Ini[$taskSection][$taskKey]) }
    }
    $taskText = ($taskLines -join "`r`n") + "`r`n"
    $taskTemp = $Path + '.aitactics.tmp'
    [void][IO.Directory]::CreateDirectory((Split-Path -Parent $Path))
    [IO.File]::WriteAllText($taskTemp, $taskText, [Text.Encoding]::Unicode)
    try {
        if ([IO.File]::Exists($Path)) { [IO.File]::Replace($taskTemp, $Path, [NullString]::Value) } else { [IO.File]::Move($taskTemp, $Path) }
    } finally { if ([IO.File]::Exists($taskTemp)) { [IO.File]::Delete($taskTemp) } }
}
function Show-FeatureMenu($Values) {
    Write-Host ''
    Write-Host '===== 설치할 기능 선택 =====' -ForegroundColor Cyan
    $taskNumber = 0
    foreach ($taskItem in $taskFeatureCatalog) {
        $taskNumber++
        if ($taskItem.Retired) { continue } # user 2026-11-03: hidden legacy keys retain OFF migration
        $taskValue = $Values[$taskItem.Section + '.' + $taskItem.Key]
        $taskOn = $taskValue -ne 0
        $taskParentOff = $taskItem.Group -and $Values['groups.' + $taskItem.Group] -eq 0
        $taskMark = if ($taskItem.Retired) { '[사용 중지]' } elseif ($taskItem.Key -eq 'terrain_diag_mode') { @('[0 기준]','[1 A]','[2 B]','[3 C]')[$taskValue] } elseif ($taskItem.Key -eq 'population_rate') { '[' + $taskValue + '배]' } elseif ($taskItem.Key -eq 'merit_troops_level') { '[' + @(1500,2000,2500,3000)[$taskValue-1] + ']' } elseif ($taskItem.Key -eq 'siege_guard_range') { '[' + @(6,8,10,12)[$taskValue-1] + '칸]' } elseif ($taskOn) { '[켬]' } else { '[끔]' }
        $taskIndent = if ($taskItem.Group) { '    ' } else { '' }
        $taskColor = if ($taskItem.Retired -or $taskParentOff) { 'DarkGray' } elseif (-not $taskItem.Group) { 'Yellow' } elseif ($taskOn) { 'Green' } else { 'Gray' }
        if (-not $taskItem.Group) { Write-Host '' }
        Write-Host ('{0}{1,2}. {2} {3}' -f $taskIndent, $taskNumber, $taskMark, $taskItem.Label) -ForegroundColor $taskColor
        if ($taskItem.Note) { Write-Host ('{0}       {1}' -f $taskIndent, $taskItem.Note) -ForegroundColor DarkGray }
    }
    Write-Host ''
    Write-Host '번호를 입력하면 켬/끔이 바뀝니다 (여러 개: 4 7 12). 지형 A/B/C 항목(0→1→2→3)과 인구 증가 배율(1→2→3→4)은 번호를 누를 때 순환하며 번호=값으로 바로 지정할 수 있습니다.'
    Write-Host '사용 중지 항목은 선택할 수 없고, 묶음이 꺼진 회색 항목은 동작하지 않습니다.'
    Write-Host 'Enter = 이대로 저장   A = 모두 켜기   D = 배포 기본값   Q = 바꾸지 않고 진행'
}
# Returns $null when the user keeps the current file unchanged (Q), otherwise the values.
function Select-Features($Values) {
    while ($true) {
        Show-FeatureMenu $Values
        $taskInput = Read-Host '선택'
        if ($null -eq $taskInput) { return $Values }
        $taskInput = $taskInput.Trim()
        if ($taskInput -eq '') { return $Values }
        if ($taskInput -ieq 'q') { return $null }
        if ($taskInput -ieq 'a') { foreach ($taskItem in $taskFeatureCatalog) { $Values[$taskItem.Section + '.' + $taskItem.Key] = if ($taskItem.Retired -or $taskItem.Key -eq 'terrain_diag_mode') { 0 } elseif ($taskItem.Key -eq 'population_rate' -or $taskItem.Key -eq 'merit_troops_level' -or $taskItem.Key -eq 'siege_guard_range') { $taskItem.Default } else { 1 } }; continue }
        if ($taskInput -ieq 'd') { foreach ($taskItem in $taskFeatureCatalog) { $Values[$taskItem.Section + '.' + $taskItem.Key] = if ($taskItem.Retired) { 0 } else { $taskItem.Default } }; continue }
        foreach ($taskToken in ($taskInput -split '[\s,]+')) {
            $taskIndex = 0
            $taskMode = 0; $taskHasMode = $false
            if ($taskToken -match '^(\d+)=(\d+)$') { $taskIndex=[int]$Matches[1]; $taskMode=[int]$Matches[2]; $taskHasMode=$true }
            elseif (-not [int]::TryParse($taskToken, [ref]$taskIndex)) { $taskIndex=0 }
            if ($taskIndex -ge 1 -and $taskIndex -le $taskFeatureCatalog.Count) {
                $taskItem = $taskFeatureCatalog[$taskIndex-1]; $taskName = $taskItem.Section + '.' + $taskItem.Key
                if ($taskItem.Retired) { $Values[$taskName] = 0; Write-Host ($taskItem.Label + ': 사용 중지') -ForegroundColor DarkGray; continue }
                if ($taskItem.Key -eq 'terrain_diag_mode') {
                    if ($taskHasMode -and ($taskMode -lt 0 -or $taskMode -gt 3)) { Write-Host 'terrain_diag_mode는 0~3만 가능합니다.' -ForegroundColor Red; continue }
                    $Values[$taskName] = if ($taskHasMode) { $taskMode } else { ($Values[$taskName]+1)%4 }
                    if ($Values[$taskName] -ne 0) { $Values['groups.diagnostics']=1 }
                } elseif ($taskItem.Key -eq 'merit_troops_level') {
                    if ($taskHasMode -and ($taskMode -lt 1 -or $taskMode -gt 4)) { Write-Host '무공 병력은 1~4(1500/2000/2500/3000)만 가능합니다.' -ForegroundColor Red; continue }
                    $Values[$taskName] = if ($taskHasMode) { $taskMode } else { $Values[$taskName]%4+1 }
                } elseif ($taskItem.Key -eq 'siege_guard_range') {
                    if ($taskHasMode -and ($taskMode -lt 1 -or $taskMode -gt 4)) { Write-Host '공성군 요격 거리는 1~4(6/8/10/12칸)만 가능합니다.' -ForegroundColor Red; continue }
                    $Values[$taskName] = if ($taskHasMode) { $taskMode } else { $Values[$taskName]%4+1 }
                } elseif ($taskItem.Key -eq 'population_rate') {
                    if ($taskHasMode -and ($taskMode -lt 1 -or $taskMode -gt 4)) { Write-Host '인구 증가 배율은 1~4만 가능합니다.' -ForegroundColor Red; continue }
                    $Values[$taskName] = if ($taskHasMode) { $taskMode } else { $Values[$taskName]%4+1 }
                } elseif ($taskHasMode) { Write-Host ('번호=값 직접 지정은 지형 A/B/C·인구 증가 배율·무공 병력·공성군 요격 거리 항목만 지원합니다: ' + $taskToken) -ForegroundColor Red }
                else { $Values[$taskName] = [int]($Values[$taskName] -eq 0) }
            } elseif ($taskToken) { Write-Host ('알 수 없는 입력: ' + $taskToken) -ForegroundColor Red }
        }
    }
}
# Interactive: menu then write. Non-interactive: keep values, rewrite in the current
# layout (older files gain the new keys with their effective values).
function Invoke-FeatureSelection([string]$Path, [bool]$Interactive) {
    $taskIni = Read-FeatureIni $Path
    $taskValues = Get-FeatureValues $taskIni
    if ($Interactive) {
        $taskChosen = Select-Features $taskValues
        if ($null -eq $taskChosen) {
            if ([IO.File]::Exists($Path)) { Write-Host '기능 설정을 바꾸지 않았습니다.'; return $false }
            $taskChosen = Get-FeatureValues @{}
        }
        $taskValues = $taskChosen
    }
    Write-FeatureIni $Path $taskValues $taskIni
    $taskOn = @($taskFeatureCatalog | Where-Object { $_.Group -and $taskValues[$_.Section + '.' + $_.Key] -ne 0 -and $taskValues['groups.' + $_.Group] -ne 0 }).Count
    Write-Host ('기능 설정을 저장했습니다: AI_TacticsMod\기능설정.ini (세부 기능 {0}개 켜짐). 게임을 다시 시작하면 적용됩니다.' -f $taskOn)
    return $true
}
